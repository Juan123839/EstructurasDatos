#include "Continente.h"
using namespace std;
Continente::Continente(){
    nombre = "";
    bonificacion = 0;
}
Continente::Continente(string nombre){
    this->nombre = nombre;
    bonificacion = 0;
    if(nombre == "America del Sur" || nombre == "Australia"){
        bonificacion = 2;
    }else if(nombre == "Africa"){
        bonificacion = 3;
    }else if(nombre == "America del Norte" || nombre == "Europa"){
        bonificacion = 5;
    }else if(nombre == "Asia"){
        bonificacion = 7;
    }
}
void Continente::agregarTerritorio(const Territorio& territorio){
    if(!contieneTerritorio(territorio.consultarCodigo())){
        territorios.push_back(territorio);
    }
}
string Continente::consultarNombre() const{
    return nombre;
}
list<Territorio>& Continente::consultarTerritorios(){
    return territorios;
}
int Continente::consultarBonificacion() const{
    return bonificacion;
}
bool Continente::contieneTerritorio(string codigo) const{
    list<Territorio>::const_iterator it;
    for(it = territorios.begin(); it != territorios.end(); it++){
        if(it->consultarCodigo() == codigo){
            return true;
        }
    }
    return false;
}
bool Continente::esControladoPor(string color) const{
    if(territorios.empty() || color == ""){
        return false;
    }
    list<Territorio>::const_iterator it;
    for(it = territorios.begin(); it != territorios.end(); it++){
        if(!it->tienePropietario() || it->consultarColorPropietario() != color){
            return false;
        }
    }
    return true;
}
int Continente::contarTerritoriosDe(string color) const{
    int contador = 0;
    list<Territorio>::const_iterator it;
    for(it = territorios.begin(); it != territorios.end(); it++){
        if(it->tienePropietario() && it->consultarColorPropietario() == color){
            contador = contador + 1;
        }
    }
    return contador;
}
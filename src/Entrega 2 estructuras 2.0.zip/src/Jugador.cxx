#include "Jugador.h"
using namespace std;
Jugador::Jugador(){
    nombre = "";
    codigo = "";
    color = "";
    unidadesDisponibles = 0;
    estado = "espera";
    conquistoEnTurno = false;
}
Jugador::Jugador(string nombre, string color){
    this->nombre = nombre;
    codigo = "";
    this->color = color;
    unidadesDisponibles = 0;
    estado = "espera";
    conquistoEnTurno = false;
}
Jugador::Jugador(string nombre, string codigo, string color){
    this->nombre = nombre;
    this->codigo = codigo;
    this->color = color;
    unidadesDisponibles = 0;
    estado = "espera";
    conquistoEnTurno = false;
}
string Jugador::consultarNombre() const{
    return nombre;
}
string Jugador::consultarCodigo() const{
    return codigo;
}
string Jugador::consultarColor() const{
    return color;
}
string Jugador::consultarEstado() const{
    return estado;
}
void Jugador::cambiarEstado(string nuevoEstado){
    if(nuevoEstado == "espera" || nuevoEstado == "ataque" || nuevoEstado == "fortificacion"){
        estado = nuevoEstado;
    }
}
bool Jugador::consultarConquistaEnTurno() const{
    return conquistoEnTurno;
}
void Jugador::registrarConquistaEnTurno(bool valor){
    conquistoEnTurno = valor;
}
void Jugador::agregarTerritorio(string codigoTerritorio){
    territorios.push_back(codigoTerritorio);
}
void Jugador::quitarTerritorio(string codigoTerritorio){
    territorios.remove(codigoTerritorio);
}
bool Jugador::tieneTerritorio(string codigoTerritorio) const{
    for(string territorio : territorios){
        if(territorio == codigoTerritorio){
            return true;
        }
    }
    return false;
}
list<string> Jugador::consultarTerritorios() const{
    return territorios;
}
bool Jugador::tieneCarta(const Carta& carta) const{
    for(const Carta& actual : cartas){
        if(actual.esIgual(carta)){
            return true;
        }
    }
    return false;
}
void Jugador::agregarCarta(const Carta& carta){
    if(!tieneCarta(carta)){
        cartas.push_back(carta);
    }
}
void Jugador::quitarCarta(int id){
    for(list<Carta>::iterator it = cartas.begin(); it != cartas.end(); it++){
        if(it->consultarIdentificador() == id){
            cartas.erase(it);
            return;
        }
    }
}
void Jugador::quitarCartas(const list<Carta>& grupoCartas){
    if(grupoCartas.size() != 3){
        return;
    }
    for(list<Carta>::const_iterator it = grupoCartas.begin(); it != grupoCartas.end(); it++){
        if(!tieneCarta(*it)){
            return;
        }
        list<Carta>::const_iterator otro = it;
        otro++;
        for(; otro != grupoCartas.end(); otro++){
            if(it->esIgual(*otro)){
                return;
            }
        }
    }
    for(const Carta& carta : grupoCartas){
        quitarCarta(carta.consultarIdentificador());
    }
}
list<Carta> Jugador::consultarCartas() const{
    return cartas;
}
int Jugador::contarCartas() const{
    return cartas.size();
}
void Jugador::agregarUnidades(int cantidad){
    if(cantidad > 0){
        unidadesDisponibles = unidadesDisponibles + cantidad;
    }
}
void Jugador::quitarUnidades(int cantidad){
    if(cantidad > 0 && cantidad <= unidadesDisponibles){
        unidadesDisponibles = unidadesDisponibles - cantidad;
    }
}
int Jugador::consultarUnidadesDisponibles() const{
    return unidadesDisponibles;
}
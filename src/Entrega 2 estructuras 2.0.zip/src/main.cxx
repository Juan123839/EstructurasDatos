#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <ctime>
#include "Interfaz.h"
#include "Juego.h"
using namespace std;
int main(){
    srand(time(0));
    Juego juego;
    string linea;
    cout << "=======================================" << endl;
    cout << "              RISK" << endl;
    cout << "Bienvenido al sistema de apoyo de Risk" << endl;
    cout << "=======================================" << endl;
    cout << "Escriba 'ayuda' para ver los comandos disponibles" << endl;
    cout << endl;
    bool continuar = true;
    while(continuar){
        cout << "$ ";
        if(!getline(cin, linea)){
            break;
        }
        vector<string> tokens = separarTokens(linea);
        continuar = procesarComando(tokens, juego);
    }
    return 0;
}
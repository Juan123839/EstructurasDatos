#ifndef JUEGO_H
#define JUEGO_H
#include <string>
#include <fstream>
#include <list>
#include <cstdint>
#include "Jugador.h"
#include "Tablero.h"
#include "Mazo.h"
class Juego {
private:
    std::list<Jugador> jugadores;
    Tablero tablero;
    Mazo mazo;
    int turnoActual;
    std::string fase;
    bool convertirNumero(std::string texto, int limite, int& numero) const;
    bool generarTextoGuardado(std::string& texto);
    bool escribirArchivoSeguro(const std::string& nombreArchivo, const std::string& contenido) const;
    void agregarEnteroBinario(std::string& contenido, std::uint64_t valor, int bytes) const;
    bool leerEnteroBinario(std::ifstream& archivo, int bytes, std::uint64_t& valor) const;
    int leerArchivoComprimido(const std::string& nombreArchivo, std::string& texto) const;
    bool extraerToken(const std::string& texto, std::string::size_type& posicion, std::string& token) const;
    int cargarTextoGuardado(const std::string& texto);
public:
    Juego();
    int inicializar(std::string nombreArchivo);
    int guardar(std::string nombreArchivo);
    int guardarComprimido(std::string nombreArchivo);
    void agregarJugador(Jugador jugador);
    std::list<Jugador>& consultarJugadores();
    Tablero& consultarTablero();
    Mazo& consultarMazo();
    Jugador* consultarJugadorActual();
    void cambiarTurno();
    std::string consultarFase() const;
    void cambiarFase(std::string nuevaFase);
    bool estaInicializado() const;
    bool estaFinalizado() const;
    Jugador* consultarGanador();
    bool existeJugador(std::string nombre) const;
    Jugador* buscarJugador(std::string nombre);
    int validarTurno(std::string nombre, std::string estadoEsperado);
    int obtenerUnidades(std::string nombre);
    std::list<std::list<Carta>> buscarCombinacionesCartas(const Jugador& jugador) const;
    int intercambiarCartas(Jugador& jugador, const std::list<Carta>& grupo);
    std::list<int> resolverRondaAtaque(Territorio& origen, Territorio& destino);
    void retirarJugador(Jugador& eliminado, Jugador& conquistador);
    int atacar(std::string nombre);
    bool entregarCarta(Jugador& jugador);
    int fortificar(std::string nombre);
    int consultarEstadoDelJuego() const;
};
#endif
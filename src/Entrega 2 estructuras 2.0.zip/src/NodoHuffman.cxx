#include "NodoHuffman.h"
NodoHuffman::NodoHuffman(unsigned char caracter, std::uint64_t frecuencia){
    this->caracter = caracter;
    this->frecuencia = frecuencia;
    hijoIzq = nullptr;
    hijoDer = nullptr;
    byteMinimo = caracter;
}
NodoHuffman::NodoHuffman(NodoHuffman* hijoIzq, NodoHuffman* hijoDer){
    caracter = 0;
    this->hijoIzq = hijoIzq;
    this->hijoDer = hijoDer;
    frecuencia = hijoIzq->consultarFrecuencia() + hijoDer->consultarFrecuencia();
    byteMinimo = hijoIzq->consultarByteMinimo();
    if(hijoDer->consultarByteMinimo() < byteMinimo){
        byteMinimo = hijoDer->consultarByteMinimo();
    }
}
NodoHuffman::~NodoHuffman(){
    delete hijoIzq;
    delete hijoDer;
}
unsigned char NodoHuffman::consultarCaracter() const{
    return caracter;
}
std::uint64_t NodoHuffman::consultarFrecuencia() const{
    return frecuencia;
}
const NodoHuffman* NodoHuffman::consultarHijoIzq() const{
    return hijoIzq;
}
const NodoHuffman* NodoHuffman::consultarHijoDer() const{
    return hijoDer;
}
unsigned char NodoHuffman::consultarByteMinimo() const{
    return byteMinimo;
}
bool NodoHuffman::esHoja() const{
    return hijoIzq == nullptr && hijoDer == nullptr;
}
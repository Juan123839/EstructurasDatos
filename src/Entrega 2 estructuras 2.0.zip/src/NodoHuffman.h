#ifndef NODOHUFFMAN_H
#define NODOHUFFMAN_H
#include <cstdint>
class NodoHuffman {
private:
    unsigned char caracter;
    std::uint64_t frecuencia;
    NodoHuffman* hijoIzq;
    NodoHuffman* hijoDer;
    unsigned char byteMinimo;
    NodoHuffman(const NodoHuffman& otro);
    NodoHuffman& operator=(const NodoHuffman& otro);
public:
    NodoHuffman(unsigned char caracter, std::uint64_t frecuencia);
    NodoHuffman(NodoHuffman* hijoIzq, NodoHuffman* hijoDer);
    ~NodoHuffman();
    unsigned char consultarCaracter() const;
    std::uint64_t consultarFrecuencia() const;
    const NodoHuffman* consultarHijoIzq() const;
    const NodoHuffman* consultarHijoDer() const;
    unsigned char consultarByteMinimo() const;
    bool esHoja() const;
};
#endif
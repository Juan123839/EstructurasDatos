  #include "Interfaz.h"
  #include "Juego.h"
  #include <string>
  #include <iostream>
  #include <list>
  #include "Territorio.h"
  #include "Jugador.h"
  #include <fstream>
  using namespace std;

  vector<string> separarTokens(string linea) {
      vector<string> tokens;
          string palabra = "";

          for (int i = 0; i < linea.size(); i++) {
              if (linea[i] == ' ') {
                  if (!palabra.empty()) {
                      tokens.push_back(palabra);
                      palabra = "";
                  }
              } else {
                  palabra += linea[i];
              }
          }
          if (!palabra.empty()) {
              tokens.push_back(palabra);
          }
      return tokens;
  }
  bool procesarComando(vector<string> tokens, Juego& juego) {

          if (tokens.empty()) {
              cout << "No se ingresaron palabras" << endl;
              return true;
          }
          if (tokens[0] == "salir") {
              if (tokens.size() > 1) {
                  cout << "Error: El comando 'salir' no debe tener argumentos" << endl;
                  return true;
              }
              return false;
          }
          if(tokens[0] == "estado_juego"){
              if(tokens.size() > 1){
                  cout << "Error: El comando 'estado_juego' no debe tener argumentos" << endl;
                  return true;
              }
              int resultado = juego.consultarEstadoDelJuego();
              if(resultado == 1){
                  cout << "Juego no inicializado: Esta partida no ha sido inicializada correctamente" << endl;
                  return true;
              }
              if(resultado == 2){
                  cout << "Juego terminado: Esta partida ya tuvo un ganador" << endl;
                  Jugador* ganador = juego.consultarGanador();
                  if(ganador != nullptr){
                      cout << "Ganador: " << ganador->consultarNombre() << " (" << ganador->consultarColor() << ")" << endl;
                  }
                  return true;
              }
              cout << "Cantidad de jugadores: " << juego.consultarJugadores().size() << endl;
              cout << endl;
              cout << "Jugadores:" << endl;
              for(Jugador jugador : juego.consultarJugadores()){
                  cout << jugador.consultarNombre() << " - " << jugador.consultarColor() << endl;
              }
              cout << endl;
              Jugador* jugadorActual = juego.consultarJugadorActual();
              if(jugadorActual != nullptr){
                  cout << "Turno actual: " << jugadorActual->consultarNombre() << endl;
              }else{
                  cout << "No hay un jugador con turno valido" << endl;
              }
              cout << "Fase actual: " << juego.consultarFase() << endl;
              cout << endl;
              cout << "Territorios:" << endl;
              list<Territorio*> territorios = juego.consultarTablero().consultarTerritorios();
              for(Territorio* territorio : territorios){
                  cout << territorio->consultarCodigo() << " - " << territorio->consultarNombre() << endl;
                  cout << "Propietario: " << territorio->consultarColorPropietario() << endl;
                  cout << "Unidades: " << territorio->consultarUnidades() << endl;
                  cout << endl;
              }
              return true;
          }

          if(tokens[0] == "atacar"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: atacar nombre_jugador" << endl;
                  return true;
              }
              int resultado = juego.atacar(tokens[1]);
              if(resultado == 0){
                  cout << "El jugador " << tokens[1] << " ha terminado de atacar" << endl;
              }else if(resultado == 1){
                  cout << "Juego no inicializado" << endl;
              }else if(resultado == 2){
                  cout << "Juego terminado: esta partida ya tuvo un ganador" << endl;
              }else if(resultado == 3){
                  cout << "Jugador no valido" << endl;
              }else if(resultado == 4){
                  cout << "Jugador fuera de turno" << endl;
              }else if(resultado == 6){
                  cout << "El jugador no ha obtenido y ubicado sus unidades" << endl;
              }else if(resultado == 8){
                  cout << "Entrada interrumpida: se conservan los combates completados" << endl;
                  return false;
              }else if(resultado == 9){
                  cout << "La ronda no pudo completarse; revise el estado de los territorios" << endl;
              }else{
                  cout << "El jugador ya termino su fase de ataque" << endl;
              }
              return true;
          }
                
          if(tokens[0] == "inicializar"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: inicializar nombre_archivo" << endl;
                  return true;
              }
              int resultado = juego.inicializar(tokens[1]);
              if(resultado == 0){
                  cout << "El juego se ha inicializado correctamente" << endl;
              }else if(resultado == 1){
                  cout << "Juego en curso: El juego ya ha sido inicializado" << endl;
              }else if(resultado == 2){
                  cout << "Archivo erroneo: no se encuentra o no puede leerse" << endl;
              }else if(resultado == 3){
                  cout << "Archivo vacio: no contiene informacion" << endl;
              }else{
                  cout << "Archivo sin formato: contiene datos invalidos o incompletos" << endl;
              }
              return true;
          }
          if(tokens[0] == "obtener_unidades"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: obtener_unidades nombre_jugador" << endl;
                  return true;
              }
              int resultado = juego.obtenerUnidades(tokens[1]);
              if(resultado == 0){
                  cout << "El jugador " << tokens[1] << " ha terminado de reclamar y ubicar sus unidades" << endl;
              }else if(resultado == 1){
                  cout << "Juego no inicializado: Esta partida no ha sido inicializada correctamente" << endl;
              }else if(resultado == 2){
                  cout << "Juego terminado: Esta partida ya tuvo un ganador" << endl;
              }else if(resultado == 3){
                  cout << "Jugador no valido: El jugador no forma parte de esta partida" << endl;
              }else if(resultado == 4){
                  cout << "Jugador fuera de turno" << endl;
              }else if(resultado == 8){
                  cout << "Entrada interrumpida: no se ubicaron refuerzos" << endl;
                  return false;
              }else{
                  cout << "El jugador ya obtuvo y ubico sus unidades en este turno" << endl;
              }
              return true;
          }
          if(tokens[0] == "fortificar"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: fortificar nombre_jugador" << endl;
                  return true;
              }
              int resultado = juego.fortificar(tokens[1]);
              if(resultado == 0){
                  cout << "El jugador " << tokens[1] << " ha terminado de fortificar su posicion" << endl;
              }else if(resultado == 1){
                  cout << "Juego no inicializado" << endl;
              }else if(resultado == 2){
                  cout << "Juego terminado: esta partida ya tuvo un ganador" << endl;
              }else if(resultado == 3){
                  cout << "Jugador no valido" << endl;
              }else if(resultado == 4){
                  cout << "Jugador fuera de turno" << endl;
              }else if(resultado == 7){
                  cout << "El jugador no ha terminado su fase de ataque" << endl;
              }else if(resultado == 8){
                  cout << "Entrada interrumpida: no se traslado ninguna unidad ni se cerro el turno" << endl;
                  return false;
              }else{
                  cout << "El jugador no puede fortificar en esta fase" << endl;
              }
              return true;
          }
          if(tokens[0] == "guardar"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: guardar nombre_archivo" << endl;
                  return true;
              }
              int resultado = juego.guardar(tokens[1]);
              if(resultado == 0){
                  cout << "La partida ha sido guardada correctamente." << endl;
              }else if(resultado == 1){
                  cout << "Esta partida no ha sido inicializada correctamente." << endl;
              }else{
                  cout << "La partida no ha sido guardada correctamente." << endl;
              }
              return true;
          }
          if(tokens[0] == "guardar_comprimido"){
              if(tokens.size() != 2){
                  cout << "Error de uso. Uso correcto: guardar_comprimido nombre_archivo" << endl;
                  return true;
              }
              int resultado = juego.guardarComprimido(tokens[1]);
              if(resultado == 0){
                  cout << "La partida ha sido codificada y guardada correctamente." << endl;
              }else if(resultado == 1){
                  cout << "Esta partida no ha sido inicializada correctamente." << endl;
              }else{
                  cout << "La partida no ha sido codificada ni guardada correctamente." << endl;
              }
              return true;
          }
          if(tokens[0] == "costo_conquista")
          {
              if(tokens.size() != 3)
              {
                  cout << "Error de uso. Uso correcto: costo_conquista nombre_jugador territorio" << endl;
                  return true;
              }

              string nombreJugador = tokens[1];
              string codigoTerritorio = tokens[2];

              string colorJugador = "";
              bool jugadorEncontrado = false;


              for(Jugador jugador : juego.consultarJugadores())
              {
                  if(jugador.consultarNombre() == nombreJugador)
                  {
                      colorJugador = jugador.consultarColor();
                      jugadorEncontrado = true;
                  }
              }


              if(!jugadorEncontrado)
              {
                  cout << "Jugador no encontrado" << endl;
                  return true;
              }


              if(!juego.consultarTablero().existeTerritorio(codigoTerritorio))
              {
                  cout << "Territorio no encontrado" << endl;
                  return true;
              }


              Territorio* encontrado = juego.consultarTablero().buscarTerritorio(codigoTerritorio);
              if(encontrado == nullptr){
                  cout << "Territorio no encontrado" << endl;
                  return true;
              }
              Territorio& territorio = *encontrado;


              if(territorio.consultarColorPropietario() == colorJugador)
              {
                  cout << "El territorio ya pertenece al jugador" << endl;
                  return true;
              }


              bool puedeAtacar = false;

              list<Territorio*> territorios = juego.consultarTablero().consultarTerritorios();

              for(Territorio* propio : territorios)
              {
                  if(propio->consultarColorPropietario() == colorJugador)
                  {
                      if(propio->esVecino(codigoTerritorio))
                      {
                          puedeAtacar = true;
                      }
                  }
              }


              if(!puedeAtacar)
              {
                  cout << "El territorio no es atacable desde los territorios del jugador" << endl;
                  return true;
              }


              cout << "Costo de conquista: "
                  << territorio.consultarUnidades()
                  << endl;


              return true;
          }
          if(tokens[0] == "conquista_mas_barata")
          {
              if(tokens.size() != 2)
              {
                  cout << "Error de uso. Uso correcto: conquista_mas_barata nombre_jugador" << endl;
                  return true;
              }


              string nombreJugador = tokens[1];
              string colorJugador = "";
              bool jugadorEncontrado = false;


              for(Jugador jugador : juego.consultarJugadores())
              {
                  if(jugador.consultarNombre() == nombreJugador)
                  {
                      colorJugador = jugador.consultarColor();
                      jugadorEncontrado = true;
                  }
              }


              if(!jugadorEncontrado)
              {
                  cout << "Jugador no encontrado" << endl;
                  return true;
              }


              Territorio* mejorTerritorio = nullptr;
              int menorCosto = 999999;


              list<Territorio*> territorios = juego.consultarTablero().consultarTerritorios();


              for(Territorio* territorio : territorios)
              {
                  if(territorio->consultarColorPropietario() != colorJugador)
                  {
                      bool puedeAtacar = false;


                      for(Territorio* propio : territorios)
                      {
                          if(propio->consultarColorPropietario() == colorJugador)
                          {
                              if(propio->esVecino(territorio->consultarCodigo()))
                              {
                                  puedeAtacar = true;
                              }
                          }
                      }


                      if(puedeAtacar)
                      {
                          int costo = territorio->consultarUnidades();


                          if(costo < menorCosto)
                          {
                              menorCosto = costo;
                              mejorTerritorio = territorio;
                          }
                      }
                  }
              }


              if(mejorTerritorio == nullptr)
              {
                  cout << "No hay territorios disponibles para conquistar" << endl;
                  return true;
              }


              cout << "Conquista mas barata:" << endl;

              cout << mejorTerritorio->consultarCodigo()
                  << " - "
                  << mejorTerritorio->consultarNombre()
                  << endl;


              cout << "Costo: "
                  << menorCosto
                  << endl;


              return true;
          }
          if (tokens[0] == "ayuda") {
              mostrarAyuda(tokens);
              return true;
          }
          cout << "Error: El comando '" << tokens[0] << "' no es reconocido" << endl;
          return true;
  }
void mostrarAyuda(vector<string> tokens){
    if(tokens.empty() || tokens.size() > 2){
        cout << "Error de uso. Uso correcto: ayuda [comando]" << endl;
        return;
    }
    if(tokens.size() == 1){
        cout << "COMANDOS DE CONFIGURACION Y JUEGO" << endl;
        cout << "inicializar nombre_archivo" << endl;
        cout << "estado_juego" << endl;
        cout << "obtener_unidades nombre_jugador" << endl;
        cout << "atacar nombre_jugador" << endl;
        cout << "fortificar nombre_jugador" << endl;
        cout << "ayuda [comando]" << endl;
        cout << "salir" << endl;
        cout << "Orden del turno: obtener_unidades, atacar y fortificar" << endl;
        cout << "Almacenamiento - Entrega 2" << endl;
        cout << "guardar nombre_archivo" << endl;
        cout << "guardar_comprimido nombre_archivo" << endl;
        cout << "costo_conquista nombre_jugador territorio" << endl;
        cout << "conquista_mas_barata nombre_jugador" << endl;
        cout << "Escriba ayuda comando para consultar su uso" << endl;
        return;
    }
    string comando = tokens[1];
    if(comando == "inicializar"){
        cout << "Uso: inicializar nombre_archivo" << endl;
        cout << "Carga un estado desde texto con el formato original o desde un comprimido con Huffman" << endl;
        cout << "La terminacion .bin selecciona la lectura comprimida; los demas nombres seleccionan texto" << endl;
        cout << "Formato: cantidad de jugadores, nombre y color de cada jugador, y los 42 territorios con propietario y unidades" << endl;
        cout << "Acepta entre 1 y 6 jugadores, sin nombres ni colores repetidos" << endl;
        cout << "Cada jugador registrado debe controlar al menos un territorio" << endl;
        cout << "Las unidades deben ser positivas y representables mediante int" << endl;
        cout << "No exige las sumas iniciales de 35, 30, 25 o 20 unidades" << endl;
        cout << "Los nombres contienen entre 1 y 8 bytes, sin separadores en blanco" << endl;
        cout << "No se permiten codigos territoriales repetidos ni desconocidos" << endl;
        cout << "El texto original puede ocupar como maximo 65536 bytes" << endl;
        cout << "No permite cargar otra partida si el juego ya esta inicializado" << endl;
        cout << "La carga comienza con el primer jugador en obtener_unidades y crea un nuevo mazo" << endl;
        cout << "No recupera el turno, la fase, las cartas ni la composicion original de figuras" << endl;
        cout << "Si un jugador controla los 42 territorios, la partida se reconoce como finalizada" << endl;
        cout << "Una carga fallida conserva el estado anterior" << endl;
    }else if(comando == "estado_juego"){
        cout << "Uso: estado_juego" << endl;
        cout << "Muestra jugadores, turno actual, fase y territorios con sus propietarios y unidades" << endl;
        cout << "Si la partida termino, informa el nombre y color del ganador" << endl;
        cout << "Si no se ha cargado una partida, informa Juego no inicializado" << endl;
        cout << "La consulta no modifica la partida" << endl;
    }else if(comando == "obtener_unidades"){
        cout << "Uso: obtener_unidades nombre_jugador" << endl;
        cout << "Requiere una partida activa y que sea el turno del jugador" << endl;
        cout << "Debe ejecutarse antes de atacar y solo una vez por turno" << endl;
        cout << "Calcula refuerzos por territorios, continentes y canjes opcionales de cartas" << endl;
        cout << "En el menu de canjes, 0 termina los intercambios" << endl;
        cout << "Despues debe distribuir todos los refuerzos en territorios propios con cantidades positivas" << endl;
        cout << "Al terminar habilita la fase de ataque" << endl;
    }else if(comando == "atacar"){
        cout << "Uso: atacar nombre_jugador" << endl;
        cout << "Requiere una partida activa, el turno del jugador y haber terminado obtener_unidades" << endl;
        cout << "Seleccione un origen propio con al menos 2 unidades y un destino enemigo vecino" << endl;
        cout << "Cada ronda informa dados y perdidas; los empates favorecen al defensor" << endl;
        cout << "En territorio origen, 0 termina la fase de ataque" << endl;
        cout << "Para continuar contra el mismo destino: 1 repite y 0 permite cambiar de ataque" << endl;
        cout << "Al conquistar debe trasladar al menos una unidad y dejar otra en el origen" << endl;
        cout << "Al terminar habilita fortificar; todavia no cambia el turno" << endl;
    }else if(comando == "fortificar"){
        cout << "Uso: fortificar nombre_jugador" << endl;
        cout << "Requiere una partida activa, el turno del jugador y haber terminado atacar" << endl;
        cout << "Elija 1 para realizar un traslado o 0 para terminar sin trasladar" << endl;
        cout << "Si elige trasladar, indique dos territorios propios, distintos y vecinos" << endl;
        cout << "La cantidad debe ser positiva y debe quedar al menos una unidad en el origen" << endl;
        cout << "En territorio origen, 0 permite terminar sin trasladar" << endl;
        cout << "Solo permite un traslado por turno" << endl;
        cout << "Si conquisto algun territorio, recibe una sola carta si quedan cartas para entregar" << endl;
        cout << "Aunque no traslade unidades, cierra el turno y pasa al siguiente jugador" << endl;
    }else if(comando == "salir"){
        cout << "Uso: salir" << endl;
        cout << "Termina el programa sin guardar automaticamente" << endl;
    }else if(comando == "ayuda"){
        cout << "Uso: ayuda [comando]" << endl;
    }else if(comando == "guardar"){
        cout << "Uso: guardar nombre_archivo" << endl;
        cout << "Requiere una partida inicializada, aunque ya tenga un ganador" << endl;
        cout << "Guarda nombres, colores y ocupacion del tablero con el formato original, sin compresion" << endl;
        cout << "No admite la terminacion .bin, reservada para el guardado comprimido" << endl;
        cout << "No guarda turnos, fases, cartas, contador de canjes ni tipos de figuras" << endl;
        cout << "El contenido se escribe en un temporal antes de reemplazar el destino" << endl;
        cout << "El guardado no modifica la partida" << endl;
    }else if(comando == "guardar_comprimido"){
        cout << "Uso: guardar_comprimido nombre_archivo" << endl;
        cout << "Requiere una partida inicializada, aunque ya tenga un ganador" << endl;
        cout << "Comprime con Huffman el mismo texto utilizado por guardar" << endl;
        cout << "Agrega .bin si el nombre no termina asi; no duplica la extension existente" << endl;
        cout << "Escribe la tabla de frecuencias, la longitud original y los bits empaquetados" << endl;
        cout << "El archivo binario no es texto legible y puede ocupar mas por su cabecera" << endl;
        cout << "El texto original puede ocupar como maximo 65536 bytes" << endl;
        cout << "Para probar su carga, abra una nueva ejecucion y use inicializar nombre_archivo.bin" << endl;
        cout << "No guarda datos adicionales ni modifica la partida" << endl;
    }else if(comando == "costo_conquista"){
        cout << "Uso: costo_conquista nombre_jugador territorio" << endl;
        cout << "Corresponde a la tercera entrega; el calculo completo de rutas esta pendiente" << endl;
    }else if(comando == "conquista_mas_barata"){
        cout << "Uso: conquista_mas_barata nombre_jugador" << endl;
        cout << "Corresponde a la tercera entrega; el calculo completo de rutas esta pendiente" << endl;
    }else{
        cout << "Error: No existe ayuda para el comando '" << comando << "'" << endl;
    }
}

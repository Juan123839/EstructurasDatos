#ifndef JUGADOR_H
#define JUGADOR_H
#include <string>
#include <list>
#include "Carta.h"
class Jugador{
private:
    std::string nombre;
    std::string codigo;
    std::string color;
    std::list<std::string> territorios;
    std::list<Carta> cartas;
    int unidadesDisponibles;
    std::string estado;
    bool conquistoEnTurno;
public:
    Jugador();
    Jugador(std::string nombre, std::string color);
    Jugador(std::string nombre, std::string codigo, std::string color);
    std::string consultarNombre() const;
    std::string consultarCodigo() const;
    std::string consultarColor() const;
    std::string consultarEstado() const;
    void cambiarEstado(std::string nuevoEstado);
    bool consultarConquistaEnTurno() const;
    void registrarConquistaEnTurno(bool valor);
    void agregarTerritorio(std::string codigoTerritorio);
    void quitarTerritorio(std::string codigoTerritorio);
    bool tieneTerritorio(std::string codigoTerritorio) const;
    std::list<std::string> consultarTerritorios() const;
    bool tieneCarta(const Carta& carta) const;
    void agregarCarta(const Carta& carta);
    void quitarCarta(int id);
    void quitarCartas(const std::list<Carta>& grupoCartas);
    std::list<Carta> consultarCartas() const;
    int contarCartas() const;
    void agregarUnidades(int cantidad);
    void quitarUnidades(int cantidad);
    int consultarUnidadesDisponibles() const;
};
#endif
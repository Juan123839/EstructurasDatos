#ifndef COLAPRIORIDADMINIMA_H
#define COLAPRIORIDADMINIMA_H
#include <vector>
#include "NodoHuffman.h"
class ColaPrioridadMinima {
private:
    std::vector<NodoHuffman*> elementos;
    bool esMenor(const NodoHuffman* primero, const NodoHuffman* segundo) const;
    void subir(int posicion);
    void bajar(int posicion);
    ColaPrioridadMinima(const ColaPrioridadMinima& otra);
    ColaPrioridadMinima& operator=(const ColaPrioridadMinima& otra);
public:
    ColaPrioridadMinima();
    ~ColaPrioridadMinima();
    bool estaVacia() const;
    int consultarCantidad() const;
    const NodoHuffman* consultarMinimo() const;
    void insertar(NodoHuffman* nodo);
    NodoHuffman* extraerMinimo();
};
#endif
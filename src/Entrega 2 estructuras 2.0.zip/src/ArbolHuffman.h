#ifndef ARBOLHUFFMAN_H
#define ARBOLHUFFMAN_H
#include <cstdint>
#include <string>
#include <vector>
#include "NodoHuffman.h"
class ArbolHuffman {
private:
    NodoHuffman* raiz;
    void generarCodigosRec(const NodoHuffman* nodo, std::string codigo, std::vector<std::string>& codigos) const;
    bool calcularLongitudRec(const NodoHuffman* nodo, std::uint64_t profundidad, std::uint64_t& longitud) const;
    void obtenerFrecuenciasRec(const NodoHuffman* nodo, std::vector<std::uint64_t>& frecuencias) const;
    ArbolHuffman(const ArbolHuffman& otro);
    ArbolHuffman& operator=(const ArbolHuffman& otro);
public:
    ArbolHuffman();
    ~ArbolHuffman();
    bool estaVacio() const;
    const NodoHuffman* consultarRaiz() const;
    bool construir(const std::vector<std::uint64_t>& frecuencias);
    std::vector<std::string> generarCodigos() const;
    bool consultarLongitudCodificada(std::uint64_t& longitud) const;
    bool codificar(const std::string& texto, std::string& bits) const;
    bool decodificar(const std::string& bits, std::uint64_t longitudOriginal, std::string& texto) const;
    void vaciar();
};
#endif
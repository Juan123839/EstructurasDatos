#include "Territorio.h"
using namespace std;
Territorio::Territorio(){
    codigo = "";
    nombre = "";
    colorPropietario = "";
}
Territorio::Territorio(string codigo, string nombre){
    this->codigo = codigo;
    this->nombre = nombre;
    colorPropietario = "";
}
string Territorio::consultarCodigo() const{
    return codigo;
}
string Territorio::consultarNombre() const{
    return nombre;
}
bool Territorio::tienePropietario() const{
    return colorPropietario != "";
}
string Territorio::consultarColorPropietario() const{
    return colorPropietario;
}
void Territorio::asignarPropietario(string color){
    colorPropietario = color;
}
list<Tropa> Territorio::consultarTropas() const{
    return tropas;
}
int Territorio::consultarUnidades() const{
    int unidades = 0;
    for(const Tropa& tropa : tropas){
        unidades = unidades + tropa.consultarEquivalencia();
    }
    return unidades;
}
void Territorio::agregarUnidades(int n){
    if(n <= 0){
        return;
    }
    for(Tropa& tropa : tropas){
        if(tropa.consultarTipo() == "infanteria"){
            tropa.agregarFiguras(n);
            return;
        }
    }
    Tropa tropa("infanteria", n);
    tropas.push_back(tropa);
}
void Territorio::quitarUnidades(int n){
    if(n <= 0 || n > consultarUnidades()){
        return;
    }
    Tropa* infanteria = nullptr;
    Tropa* caballeria = nullptr;
    Tropa* artilleria = nullptr;
    for(Tropa& tropa : tropas){
        if(tropa.consultarTipo() == "infanteria"){
            infanteria = &tropa;
        }else if(tropa.consultarTipo() == "caballeria"){
            caballeria = &tropa;
        }else if(tropa.consultarTipo() == "artilleria"){
            artilleria = &tropa;
        }
    }
    if(infanteria == nullptr){
        tropas.push_back(Tropa("infanteria", 0));
        infanteria = &tropas.back();
    }
    while(infanteria->consultarCantidad() < n){
        if(caballeria != nullptr && !caballeria->estaVacia()){
            caballeria->quitarFiguras(1);
            agregarUnidades(5);
        }else if(artilleria != nullptr && !artilleria->estaVacia()){
            artilleria->quitarFiguras(1);
            agregarUnidades(10);
        }else{
            return;
        }
    }
    infanteria->quitarFiguras(n);
    list<Tropa>::iterator it = tropas.begin();
    while(it != tropas.end()){
        if(it->estaVacia()){
            it = tropas.erase(it);
        }else{
            it++;
        }
    }
}
void Territorio::reagrupar(){
    Tropa* infanteria = nullptr;
    Tropa* caballeria = nullptr;
    Tropa* artilleria = nullptr;
    for(Tropa& tropa : tropas){
        if(tropa.consultarTipo() == "infanteria"){
            infanteria = &tropa;
        }else if(tropa.consultarTipo() == "caballeria"){
            caballeria = &tropa;
        }else if(tropa.consultarTipo() == "artilleria"){
            artilleria = &tropa;
        }
    }
    if(infanteria == nullptr){
        return;
    }
    int cantidadArtilleria = infanteria->consultarCantidad() / 10;
    if(cantidadArtilleria > 0){
        infanteria->quitarFiguras(cantidadArtilleria * 10);
        if(artilleria == nullptr){
            tropas.push_back(Tropa("artilleria", cantidadArtilleria));
        }else{
            artilleria->agregarFiguras(cantidadArtilleria);
        }
    }
    int cantidadCaballeria = infanteria->consultarCantidad() / 5;
    if(cantidadCaballeria > 0){
        infanteria->quitarFiguras(cantidadCaballeria * 5);
        if(caballeria == nullptr){
            tropas.push_back(Tropa("caballeria", cantidadCaballeria));
        }else{
            caballeria->agregarFiguras(cantidadCaballeria);
        }
    }
    list<Tropa>::iterator it = tropas.begin();
    while(it != tropas.end()){
        if(it->estaVacia()){
            it = tropas.erase(it);
        }else{
            it++;
        }
    }
}
void Territorio::agregarVecino(string codigoVecino){
    if(codigoVecino != "" && codigoVecino != codigo && !esVecino(codigoVecino)){
        vecinos.push_back(codigoVecino);
    }
}
bool Territorio::esVecino(string codigoVecino) const{
    for(string vecino : vecinos){
        if(vecino == codigoVecino){
            return true;
        }
    }
    return false;
}
list<string> Territorio::consultarVecinos() const{
    return vecinos;
}
#include "Mazo.h"
#include <cstdlib>
using namespace std;
Mazo::Mazo(){
    grupos = 0;
}
void Mazo::barajar(){
    list<Carta> mezcladas;
    while(!disponibles.empty()){
        int posicion = rand() % disponibles.size();
        list<Carta>::iterator it = disponibles.begin();
        for(int i = 0; i < posicion; i++){
            it++;
        }
        mezcladas.push_back(*it);
        disponibles.erase(it);
    }
    disponibles = mezcladas;
}
void Mazo::crearMazo(Tablero& tablero){
    disponibles.clear();
    descartadas.clear();
    grupos = 0;
    if(tablero.consultarTerritorios().size() != 42){
        return;
    }
    int id = 1;
    list<Continente>& continentes = tablero.consultarContinentes();
    for(Continente& continente : continentes){
        list<Territorio>& territorios = continente.consultarTerritorios();
        for(Territorio& territorio : territorios){
            string simbolo;
            if((id - 1) % 3 == 0){
                simbolo = "infanteria";
            }else if((id - 1) % 3 == 1){
                simbolo = "caballeria";
            }else{
                simbolo = "artilleria";
            }
            Carta carta(id, "territorio", territorio.consultarCodigo(), simbolo);
            disponibles.push_back(carta);
            id++;
        }
    }
    Carta comodin1(43, "comodin", "", "comodin");
    Carta comodin2(44, "comodin", "", "comodin");
    disponibles.push_back(comodin1);
    disponibles.push_back(comodin2);
    barajar();
}
bool Mazo::estaVacio() const{
    return disponibles.empty() && descartadas.empty();
}
int Mazo::contarCartasDisponibles() const{
    return disponibles.size();
}
Carta Mazo::repartirCarta(){
    if(estaVacio()){
        return Carta();
    }
    if(disponibles.empty()){
        disponibles = descartadas;
        descartadas.clear();
        barajar();
    }
    Carta carta = disponibles.front();
    disponibles.pop_front();
    return carta;
}
void Mazo::descartarCartas(const list<Carta>& grupo){
    if(grupo.size() != 3){
        return;
    }
    int identificadores[3];
    int cantidad = 0;
    for(const Carta& carta : grupo){
        int id = carta.consultarIdentificador();
        if(id < 1 || id > 44){
            return;
        }
        for(int i = 0; i < cantidad; i++){
            if(identificadores[i] == id){
                return;
            }
        }
        for(const Carta& disponible : disponibles){
            if(disponible.esIgual(carta)){
                return;
            }
        }
        for(const Carta& descartada : descartadas){
            if(descartada.esIgual(carta)){
                return;
            }
        }
        identificadores[cantidad] = id;
        cantidad++;
    }
    for(const Carta& carta : grupo){
        descartadas.push_back(carta);
    }
    grupos++;
}
int Mazo::consultarUnidadesPorIntercambio() const{
    int k = grupos + 1;
    if(k == 1){
        return 4;
    }else if(k == 2){
        return 6;
    }else if(k == 3){
        return 8;
    }else if(k == 4){
        return 10;
    }else if(k == 5){
        return 12;
    }else if(k == 6){
        return 15;
    }
    return 15 + (k - 6) * 5;
}
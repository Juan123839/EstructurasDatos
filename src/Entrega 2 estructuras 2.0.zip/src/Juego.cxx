#include "Juego.h"
#include "ArbolHuffman.h"
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <vector>
#include <climits>
#include <cctype>
#include <cstdio>
#include <unistd.h>
using namespace std;

Juego::Juego(){
    turnoActual = 0;
    fase = "inicio";
    tablero.crearTablero();
    mazo.crearMazo(tablero);
}

int Juego::inicializar(string nombreArchivo){
    if(estaInicializado()){
        return 1;
    }
    if(nombreArchivo.empty() || nombreArchivo.find('\0') != string::npos){
        return 2;
    }
    bool comprimido = nombreArchivo.size() >= 4 && nombreArchivo.substr(nombreArchivo.size() - 4) == ".bin";
    string texto;
    if(comprimido){
        int resultado = leerArchivoComprimido(nombreArchivo, texto);
        if(resultado != 0){
            return resultado;
        }
    }else{
        ifstream archivo(nombreArchivo, ios::binary);
        if(!archivo.is_open()){
            return 2;
        }
        if(archivo.peek() == EOF){
            return archivo.bad() ? 2 : 3;
        }
        archivo.seekg(0, ios::end);
        streamoff tamano = archivo.tellg();
        if(tamano < 0){
            return 2;
        }
        if(tamano == 0){
            return 3;
        }
        if(tamano > 65536){
            return 4;
        }
        archivo.seekg(0, ios::beg);
        if(!archivo){
            return 2;
        }
        texto.resize((string::size_type)tamano);
        if(!archivo.read(&texto[0], (streamsize)tamano)){
            return archivo.bad() ? 2 : 4;
        }
        if(archivo.peek() != EOF){
            return 4;
        }
        if(archivo.bad()){
            return 2;
        }
    }
    int resultado = cargarTextoGuardado(texto);
    if(comprimido && resultado == 3){
        return 4;
    }
    return resultado;
}


void Juego::agregarJugador(Jugador jugador)
{
    jugadores.push_back(jugador);
}

list<Jugador>& Juego::consultarJugadores()
{
    return jugadores;
}

Tablero& Juego::consultarTablero()
{
    return tablero;
}

Mazo& Juego::consultarMazo()
{
    return mazo;
}

Jugador* Juego::consultarJugadorActual(){
    if(turnoActual < 0 || turnoActual >= (int)jugadores.size()){
        return nullptr;
    }
    list<Jugador>::iterator it = jugadores.begin();
    for(int i = 0; i < turnoActual; i++){
        it++;
    }
    return &(*it);
}

void Juego::cambiarTurno(){
    Jugador* jugadorActual = consultarJugadorActual();
    if(jugadorActual == nullptr){
        return;
    }
    jugadorActual->cambiarEstado("espera");
    jugadorActual->registrarConquistaEnTurno(false);
    turnoActual++;
    if(turnoActual >= (int)jugadores.size()){
        turnoActual = 0;
    }
    fase = "obtener_unidades";
}

string Juego::consultarFase() const
{
    return fase;
}

void Juego::cambiarFase(string nuevaFase)
{
    fase = nuevaFase;
}
bool Juego::existeJugador(string nombre) const{
    for(const Jugador& jugador : jugadores){
        if(jugador.consultarNombre() == nombre){
            return true;
        }
    }
    return false;
}
Jugador* Juego::buscarJugador(string nombre){
    for(Jugador& jugador : jugadores){
        if(jugador.consultarNombre() == nombre){
            return &jugador;
        }
    }
    return nullptr;
}
int Juego::validarTurno(string nombre, string estadoEsperado){
    if(!estaInicializado()){
        return 1;
    }
    if(estaFinalizado()){
        return 2;
    }
    Jugador* jugador = buscarJugador(nombre);
    if(jugador == nullptr){
        return 3;
    }
    if(jugador != consultarJugadorActual()){
        return 4;
    }
    string estadoActual = jugador->consultarEstado();
    if(estadoActual == estadoEsperado){
        return 0;
    }
    if(estadoEsperado == "ataque" && estadoActual == "espera"){
        return 6;
    }
    if(estadoEsperado == "fortificacion"){
        return 7;
    }
    return 5;
}
bool Juego::convertirNumero(string texto, int limite, int& numero) const{
    numero = 0;
    if(texto.empty() || limite < 0){
        return false;
    }
    for(int i = 0; i < (int)texto.size(); i++){
        if(texto[i] < '0' || texto[i] > '9'){
            return false;
        }
        int digito = texto[i] - '0';
        if(numero > limite / 10 || (numero == limite / 10 && digito > limite % 10)){
            return false;
        }
        numero = numero * 10 + digito;
    }
    return true;
}
int Juego::obtenerUnidades(string nombre){
    int resultado = validarTurno(nombre, "espera");
    if(resultado != 0){
        return resultado;
    }
    Jugador* jugador = buscarJugador(nombre);
    Juego temporal = *this;
    Jugador* jugadorTemporal = temporal.buscarJugador(nombre);
    string color = jugadorTemporal->consultarColor();
    int porTerritorios = tablero.contarTerritoriosDe(color) / 3;
    int porContinentes = tablero.calcularBonificacionPorContinentes(color);
    int restantes = porTerritorios + porContinentes;
    cout << "Refuerzos por territorios: " << porTerritorios << endl;
    cout << "Bonificacion por continentes: " << porContinentes << endl;
    while(true){
        list<list<Carta>> grupos = temporal.buscarCombinacionesCartas(*jugadorTemporal);
        if(grupos.empty()){
            break;
        }
        int numeroGrupo = 1;
        cout << "Grupos disponibles para intercambiar:" << endl;
        for(const list<Carta>& grupo : grupos){
            cout << numeroGrupo << ": ";
            for(const Carta& carta : grupo){
                cout << "[" << carta.consultarIdentificador() << " " << carta.consultarSimbolo();
                if(carta.tieneTerritorio()){
                    cout << " " << carta.consultarCodigoTerritorio();
                }
                cout << "] ";
            }
            cout << endl;
            numeroGrupo++;
        }
        cout << "Elija un grupo, o 0 para no intercambiar: ";
        string entrada;
        if(!getline(cin, entrada)){
            return 8;
        }
        int opcion;
        if(!convertirNumero(entrada, (int)grupos.size(), opcion)){
            cout << "Opcion invalida" << endl;
            continue;
        }
        if(opcion == 0){
            break;
        }
        list<list<Carta>>::const_iterator itGrupo = grupos.begin();
        for(int i = 1; i < opcion; i++){
            itGrupo++;
        }
        int unidades = temporal.intercambiarCartas(*jugadorTemporal, *itGrupo);
        if(unidades == 0){
            cout << "No se pudo realizar ese canje" << endl;
            continue;
        }
        restantes += unidades;
        cout << "Refuerzos del canje: " << unidades << endl;
        for(const Carta& carta : *itGrupo){
            if(carta.tieneTerritorio()){
                Territorio* territorio = temporal.tablero.buscarTerritorio(carta.consultarCodigoTerritorio());
                if(territorio != nullptr && territorio->tienePropietario() && territorio->consultarColorPropietario() == color){
                    cout << "Bono obligatorio: 2 unidades en " << territorio->consultarCodigo() << endl;
                }
            }
        }
    }
    cout << "Unidades obtenidas: " << restantes << endl;
    while(restantes > 0){
        cout << "Unidades restantes: " << restantes << endl;
        cout << "Codigo del territorio propio: ";
        string codigo;
        if(!getline(cin, codigo)){
            return 8;
        }
        Territorio* territorio = temporal.tablero.buscarTerritorio(codigo);
        if(territorio == nullptr){
            cout << "Territorio no encontrado" << endl;
            continue;
        }
        if(!territorio->tienePropietario() || territorio->consultarColorPropietario() != color){
            cout << "El territorio no pertenece al jugador" << endl;
            continue;
        }
        cout << "Cantidad de unidades: ";
        string entrada;
        if(!getline(cin, entrada)){
            return 8;
        }
        int cantidad;
        if(!convertirNumero(entrada, restantes, cantidad) || cantidad == 0){
            cout << "Ingrese un entero entre 1 y " << restantes << endl;
            continue;
        }
        territorio->agregarUnidades(cantidad);
        restantes -= cantidad;
    }
    list<Territorio*> originales = tablero.consultarTerritorios();
    list<Territorio*> copias = temporal.tablero.consultarTerritorios();
    list<Territorio*>::iterator itCopia = copias.begin();
    for(Territorio* original : originales){
        int incremento = (*itCopia)->consultarUnidades() - original->consultarUnidades();
        original->agregarUnidades(incremento);
        itCopia++;
    }
    *jugador = *jugadorTemporal;
    mazo = temporal.mazo;
    jugador->cambiarEstado("ataque");
    fase = "ataque";
    return 0;
}
list<list<Carta>> Juego::buscarCombinacionesCartas(const Jugador& jugador) const{
    list<list<Carta>> combinaciones;
    list<Carta> cartas = jugador.consultarCartas();
    for(list<Carta>::const_iterator primera = cartas.begin(); primera != cartas.end(); primera++){
        list<Carta>::const_iterator segunda = primera;
        segunda++;
        for(; segunda != cartas.end(); segunda++){
            list<Carta>::const_iterator tercera = segunda;
            tercera++;
            for(; tercera != cartas.end(); tercera++){
                string simbolo1 = primera->consultarSimbolo();
                string simbolo2 = segunda->consultarSimbolo();
                string simbolo3 = tercera->consultarSimbolo();
                bool iguales = simbolo1 == simbolo2 && simbolo2 == simbolo3;
                bool diferentes = simbolo1 != simbolo2 && simbolo1 != simbolo3 && simbolo2 != simbolo3;
                bool comodin = primera->consultarTipo() == "comodin" || segunda->consultarTipo() == "comodin" || tercera->consultarTipo() == "comodin";
                if(iguales || diferentes || comodin){
                    list<Carta> grupo;
                    grupo.push_back(*primera);
                    grupo.push_back(*segunda);
                    grupo.push_back(*tercera);
                    combinaciones.push_back(grupo);
                }
            }
        }
    }
    return combinaciones;
}
int Juego::intercambiarCartas(Jugador& jugador, const list<Carta>& grupo){
    if(buscarJugador(jugador.consultarNombre()) != &jugador || grupo.size() != 3){
        return 0;
    }
    list<list<Carta>> combinaciones = buscarCombinacionesCartas(jugador);
    list<Carta> grupoValido;
    for(const list<Carta>& combinacion : combinaciones){
        int coincidencias = 0;
        for(const Carta& carta : combinacion){
            for(const Carta& elegida : grupo){
                if(carta.esIgual(elegida)){
                    coincidencias++;
                    break;
                }
            }
        }
        if(coincidencias == 3){
            grupoValido = combinacion;
            break;
        }
    }
    if(grupoValido.empty()){
        return 0;
    }
    int unidades = mazo.consultarUnidadesPorIntercambio();
    Mazo mazoTemporal = mazo;
    mazoTemporal.descartarCartas(grupoValido);
    if(mazoTemporal.consultarUnidadesPorIntercambio() == unidades){
        return 0;
    }
    jugador.quitarCartas(grupoValido);
    mazo = mazoTemporal;
    for(const Carta& carta : grupoValido){
        if(carta.tieneTerritorio()){
            Territorio* territorio = tablero.buscarTerritorio(carta.consultarCodigoTerritorio());
            if(territorio != nullptr && territorio->tienePropietario() && territorio->consultarColorPropietario() == jugador.consultarColor()){
                territorio->agregarUnidades(2);
            }
        }
    }
    return unidades;
}
list<int> Juego::resolverRondaAtaque(Territorio& origen, Territorio& destino){
    list<int> resultado;
    if(&origen == &destino || origen.consultarUnidades() < 2 || destino.consultarUnidades() < 1){
        return resultado;
    }
    if(!origen.tienePropietario() || !destino.tienePropietario()){
        return resultado;
    }
    if(origen.consultarColorPropietario() == destino.consultarColorPropietario() || !origen.esVecino(destino.consultarCodigo())){
        return resultado;
    }
    int dadosAtaque[3];
    int dadosDefensa[2];
    for(int i = 0; i < 3; i++){
        dadosAtaque[i] = rand() % 6 + 1;
    }
    for(int i = 0; i < 2; i++){
        dadosDefensa[i] = rand() % 6 + 1;
    }
    for(int i = 0; i < 2; i++){
        for(int j = i + 1; j < 3; j++){
            if(dadosAtaque[j] > dadosAtaque[i]){
                int auxiliar = dadosAtaque[i];
                dadosAtaque[i] = dadosAtaque[j];
                dadosAtaque[j] = auxiliar;
            }
        }
    }
    if(dadosDefensa[1] > dadosDefensa[0]){
        int auxiliar = dadosDefensa[0];
        dadosDefensa[0] = dadosDefensa[1];
        dadosDefensa[1] = auxiliar;
    }
    int comparaciones = 2;
    if(origen.consultarUnidades() - 1 < comparaciones){
        comparaciones = origen.consultarUnidades() - 1;
    }
    if(destino.consultarUnidades() < comparaciones){
        comparaciones = destino.consultarUnidades();
    }
    int perdidasAtacante = 0;
    int perdidasDefensor = 0;
    for(int i = 0; i < comparaciones; i++){
        if(dadosAtaque[i] > dadosDefensa[i]){
            perdidasDefensor++;
        }else{
            perdidasAtacante++;
        }
    }
    if(perdidasAtacante > 0){
        origen.quitarUnidades(perdidasAtacante);
    }
    if(perdidasDefensor > 0){
        destino.quitarUnidades(perdidasDefensor);
    }
    for(int i = 0; i < 3; i++){
        resultado.push_back(dadosAtaque[i]);
    }
    for(int i = 0; i < 2; i++){
        resultado.push_back(dadosDefensa[i]);
    }
    resultado.push_back(perdidasAtacante);
    resultado.push_back(perdidasDefensor);
    return resultado;
}
void Juego::retirarJugador(Jugador& eliminado, Jugador& conquistador){
    if(&eliminado == &conquistador){
        return;
    }
    if(buscarJugador(eliminado.consultarNombre()) != &eliminado || buscarJugador(conquistador.consultarNombre()) != &conquistador){
        return;
    }
    if(tablero.contarTerritoriosDe(eliminado.consultarColor()) != 0){
        return;
    }
    Jugador* actual = consultarJugadorActual();
    if(actual == nullptr || actual == &eliminado){
        actual = &conquistador;
    }
    for(list<Jugador>::iterator it = jugadores.begin(); it != jugadores.end(); it++){
        if(&(*it) == &eliminado){
            for(const Carta& carta : eliminado.consultarCartas()){
                conquistador.agregarCarta(carta);
            }
            jugadores.erase(it);
            turnoActual = 0;
            for(Jugador& jugador : jugadores){
                if(&jugador == actual){
                    break;
                }
                turnoActual++;
            }
            return;
        }
    }
}
bool Juego::estaInicializado() const{
    return !jugadores.empty();
}

bool Juego::estaFinalizado() const{
    for(const Jugador& jugador : jugadores){
        if(tablero.controlaTodoElTablero(jugador.consultarColor())){
            return true;
        }
    }
    return false;
}
int Juego::atacar(string nombre){
    int resultado = validarTurno(nombre, "ataque");
    if(resultado != 0){
        return resultado;
    }
    Jugador* jugador = buscarJugador(nombre);
    string color = jugador->consultarColor();
    string entrada;
    while(!estaFinalizado()){
        cout << "Territorio origen (0 para terminar la fase): ";
        if(!getline(cin, entrada)){
            return 8;
        }
        if(entrada == "0"){
            break;
        }
        Territorio* origen = tablero.buscarTerritorio(entrada);
        if(origen == nullptr){
            cout << "Territorio origen no encontrado" << endl;
            continue;
        }
        if(!origen->tienePropietario() || origen->consultarColorPropietario() != color){
            cout << "El territorio origen no pertenece al jugador" << endl;
            continue;
        }
        if(origen->consultarUnidades() < 2){
            cout << "No hay suficientes unidades para atacar" << endl;
            continue;
        }
        cout << "Territorio destino: ";
        if(!getline(cin, entrada)){
            return 8;
        }
        Territorio* destino = tablero.buscarTerritorio(entrada);
        if(destino == nullptr){
            cout << "Territorio destino no encontrado" << endl;
            continue;
        }
        if(!destino->tienePropietario() || destino->consultarUnidades() < 1){
            cout << "El territorio destino no tiene una defensa valida" << endl;
            continue;
        }
        if(destino->consultarColorPropietario() == color){
            cout << "No se puede atacar un territorio propio" << endl;
            continue;
        }
        if(!origen->esVecino(destino->consultarCodigo())){
            cout << "Los territorios no son vecinos" << endl;
            continue;
        }
        Jugador* defensor = nullptr;
        for(Jugador& rival : jugadores){
            if(rival.consultarColor() == destino->consultarColorPropietario()){
                defensor = &rival;
                break;
            }
        }
        if(defensor == nullptr){
            cout << "El propietario del destino no es un jugador activo" << endl;
            continue;
        }
        while(origen->consultarUnidades() > 1){
            Territorio copiaOrigen = *origen;
            Territorio copiaDestino = *destino;
            list<int> ronda = resolverRondaAtaque(copiaOrigen, copiaDestino);
            if(ronda.size() != 7){
                cout << "No fue posible resolver la ronda" << endl;
                return 9;
            }
            int datos[7];
            int posicion = 0;
            for(int valor : ronda){
                datos[posicion] = valor;
                posicion++;
            }
            cout << "Dados atacante: " << datos[0] << " " << datos[1] << " " << datos[2] << endl;
            cout << "Dados defensor: " << datos[3] << " " << datos[4] << endl;
            cout << "Perdidas atacante: " << datos[5] << ", defensor: " << datos[6] << endl;
            bool conquistado = copiaDestino.consultarUnidades() == 0;
            if(conquistado){
                int limite = copiaOrigen.consultarUnidades() - 1;
                int cantidad = 0;
                bool cantidadValida = false;
                while(!cantidadValida){
                    cout << "Unidades a trasladar (1 a " << limite << "): ";
                    if(!getline(cin, entrada)){
                        cout << "La ultima ronda no se aplico porque falta completar el traslado" << endl;
                        return 8;
                    }
                    cantidadValida = convertirNumero(entrada, limite, cantidad) && cantidad > 0;
                    if(!cantidadValida){
                        cout << "Cantidad no valida" << endl;
                    }
                }
                copiaOrigen.quitarUnidades(cantidad);
                copiaDestino.asignarPropietario(color);
                copiaDestino.agregarUnidades(cantidad);
            }
            *origen = copiaOrigen;
            *destino = copiaDestino;
            if(conquistado){
                jugador->agregarTerritorio(destino->consultarCodigo());
                defensor->quitarTerritorio(destino->consultarCodigo());
                jugador->registrarConquistaEnTurno(true);
                cout << "Territorio conquistado: " << destino->consultarCodigo() << endl;
                if(tablero.contarTerritoriosDe(defensor->consultarColor()) == 0){
                    string nombreEliminado = defensor->consultarNombre();
                    retirarJugador(*defensor, *jugador);
                    cout << "Jugador eliminado: " << nombreEliminado << endl;
                }
                break;
            }
            if(origen->consultarUnidades() == 1){
                cout << "El territorio origen ya no tiene unidades para atacar" << endl;
                break;
            }
            int opcion = 0;
            bool opcionValida = false;
            while(!opcionValida){
                cout << "Continuar contra este territorio (1: si, 0: cambiar): ";
                if(!getline(cin, entrada)){
                    return 8;
                }
                opcionValida = convertirNumero(entrada, 1, opcion);
                if(!opcionValida){
                    cout << "Opcion no valida" << endl;
                }
            }
            if(opcion == 0){
                break;
            }
        }
    }
    jugador->cambiarEstado("fortificacion");
    fase = "fortificacion";
    if(estaFinalizado()){
        cout << "Ganador: " << jugador->consultarNombre() << endl;
    }
    return 0;
}
bool Juego::entregarCarta(Jugador& jugador){
    if(buscarJugador(jugador.consultarNombre()) != &jugador || !jugador.consultarConquistaEnTurno()){
        return false;
    }
    if(mazo.estaVacio()){
        return false;
    }
    Carta carta = mazo.repartirCarta();
    jugador.agregarCarta(carta);
    return true;
}
int Juego::fortificar(string nombre){
    int resultado = validarTurno(nombre, "fortificacion");
    if(resultado != 0){
        return resultado;
    }
    Jugador* jugador = buscarJugador(nombre);
    string color = jugador->consultarColor();
    string entrada;
    int opcion = 0;
    bool opcionValida = false;
    while(!opcionValida){
        cout << "Desea fortificar (1: si, 0: terminar sin trasladar): ";
        if(!getline(cin, entrada)){
            return 8;
        }
        opcionValida = convertirNumero(entrada, 1, opcion);
        if(!opcionValida){
            cout << "Opcion no valida" << endl;
        }
    }
    while(opcion == 1){
        cout << "Territorio origen (0 para terminar sin trasladar): ";
        if(!getline(cin, entrada)){
            return 8;
        }
        if(entrada == "0"){
            break;
        }
        Territorio* origen = tablero.buscarTerritorio(entrada);
        if(origen == nullptr){
            cout << "Territorio origen no encontrado" << endl;
            continue;
        }
        if(!origen->tienePropietario() || origen->consultarColorPropietario() != color){
            cout << "El territorio origen no pertenece al jugador" << endl;
            continue;
        }
        if(origen->consultarUnidades() < 2){
            cout << "Debe quedar al menos una unidad en el origen" << endl;
            continue;
        }
        cout << "Territorio destino: ";
        if(!getline(cin, entrada)){
            return 8;
        }
        Territorio* destino = tablero.buscarTerritorio(entrada);
        if(destino == nullptr){
            cout << "Territorio destino no encontrado" << endl;
            continue;
        }
        if(!destino->tienePropietario() || destino->consultarColorPropietario() != color){
            cout << "El territorio destino no pertenece al jugador" << endl;
            continue;
        }
        if(origen == destino || !origen->esVecino(destino->consultarCodigo())){
            cout << "Seleccione dos territorios distintos y vecinos" << endl;
            continue;
        }
        int limite = origen->consultarUnidades() - 1;
        int cantidad = 0;
        bool cantidadValida = false;
        while(!cantidadValida){
            cout << "Cantidad de unidades (1 a " << limite << "): ";
            if(!getline(cin, entrada)){
                return 8;
            }
            cantidadValida = convertirNumero(entrada, limite, cantidad) && cantidad > 0;
            if(!cantidadValida){
                cout << "Cantidad no valida" << endl;
            }
        }
        origen->quitarUnidades(cantidad);
        destino->agregarUnidades(cantidad);
        cout << "Fortificacion realizada correctamente" << endl;
        break;
    }
    if(jugador->consultarConquistaEnTurno()){
        if(entregarCarta(*jugador)){
            cout << "Recibio una carta por conquistar durante el turno" << endl;
        }else{
            cout << "No quedan cartas para entregar" << endl;
        }
    }
    cambiarTurno();
    Jugador* siguiente = consultarJugadorActual();
    if(siguiente != nullptr){
        cout << "Turno actual: " << siguiente->consultarNombre() << endl;
    }
    return 0;
}
Jugador* Juego::consultarGanador(){
    for(Jugador& jugador : jugadores){
        if(tablero.controlaTodoElTablero(jugador.consultarColor())){
            return &jugador;
        }
    }
    return nullptr;
}
int Juego::consultarEstadoDelJuego() const{
    if(!estaInicializado()){
        return 1;
    }
    if(estaFinalizado()){
        return 2;
    }
    return 0;
}
bool Juego::generarTextoGuardado(string& texto){
    if(jugadores.empty() || jugadores.size() > 6){
        return false;
    }
    list<Territorio*> territorios = tablero.consultarTerritorios();
    if(territorios.size() != 42){
        return false;
    }
    string temporal = to_string(jugadores.size()) + "\n";
    for(const Jugador& jugador : jugadores){
        string nombre = jugador.consultarNombre();
        string color = jugador.consultarColor();
        if(nombre.empty() || nombre.size() > 8){
            return false;
        }
        for(unsigned char caracter : nombre){
            if(caracter == 0 || isspace(caracter)){
                return false;
            }
        }
        if(color != "rojo" && color != "azul" && color != "verde" && color != "amarillo" && color != "negro" && color != "gris"){
            return false;
        }
        int coincidencias = 0;
        for(const Jugador& otro : jugadores){
            if(otro.consultarNombre() == nombre || otro.consultarColor() == color){
                coincidencias++;
            }
        }
        if(coincidencias != 1){
            return false;
        }
        list<string> propios = jugador.consultarTerritorios();
        if(propios.empty() || propios.size() > 42){
            return false;
        }
        if((int)propios.size() != tablero.contarTerritoriosDe(color)){
            return false;
        }
        list<string> revisados;
        for(const string& codigo : propios){
            for(const string& anterior : revisados){
                if(anterior == codigo){
                    return false;
                }
            }
            Territorio* territorio = tablero.buscarTerritorio(codigo);
            if(territorio == nullptr || territorio->consultarColorPropietario() != color){
                return false;
            }
            revisados.push_back(codigo);
        }
        temporal += nombre + " " + color + "\n";
    }
    Tablero referencia;
    referencia.crearTablero();
    list<Territorio*> orden = referencia.consultarTerritorios();
    for(const Territorio* oficial : orden){
        string codigo = oficial->consultarCodigo();
        Territorio* encontrado = nullptr;
        for(Territorio* candidato : territorios){
            if(candidato == nullptr){
                return false;
            }
            if(candidato->consultarCodigo() == codigo){
                if(encontrado != nullptr){
                    return false;
                }
                encontrado = candidato;
            }
        }
        if(encontrado == nullptr || !encontrado->tienePropietario()){
            return false;
        }
        string color = encontrado->consultarColorPropietario();
        bool propietarioValido = false;
        for(const Jugador& jugador : jugadores){
            if(jugador.consultarColor() == color){
                propietarioValido = true;
                break;
            }
        }
        if(!propietarioValido){
            return false;
        }
        int unidades = 0;
        bool tipos[3] = {false, false, false};
        list<Tropa> tropas = encontrado->consultarTropas();
        for(const Tropa& tropa : tropas){
            string tipo = tropa.consultarTipo();
            int indice = -1;
            if(tipo == "infanteria"){
                indice = 0;
            }else if(tipo == "caballeria"){
                indice = 1;
            }else if(tipo == "artilleria"){
                indice = 2;
            }else{
                return false;
            }
            if(tipos[indice]){
                return false;
            }
            tipos[indice] = true;
            int cantidad = tropa.consultarCantidad();
            int valor = tropa.consultarValorUnitario();
            if(cantidad <= 0 || valor <= 0){
                return false;
            }
            if(cantidad > (INT_MAX - unidades) / valor){
                return false;
            }
            unidades += cantidad * valor;
        }
        if(unidades <= 0){
            return false;
        }
        temporal += codigo + " " + color + " " + to_string(unidades) + "\n";
        if(temporal.size() > 65536){
            return false;
        }
    }
    texto.swap(temporal);
    return true;
}
bool Juego::escribirArchivoSeguro(const string& nombreArchivo, const string& contenido) const{
    if(nombreArchivo.empty() || nombreArchivo.find('\0') != string::npos){
        return false;
    }
    string plantilla = nombreArchivo + ".tmp.XXXXXX";
    vector<char> nombreTemporal(plantilla.begin(), plantilla.end());
    nombreTemporal.push_back('\0');
    int descriptor = mkstemp(nombreTemporal.data());
    if(descriptor == -1){
        return false;
    }
    FILE* archivo = fdopen(descriptor, "wb");
    if(archivo == nullptr){
        close(descriptor);
        std::remove(nombreTemporal.data());
        return false;
    }
    bool correcto = fwrite(contenido.data(), 1, contenido.size(), archivo) == contenido.size();
    if(fclose(archivo) != 0){
        correcto = false;
    }
    if(!correcto){
        std::remove(nombreTemporal.data());
        return false;
    }
    if(std::rename(nombreTemporal.data(), nombreArchivo.c_str()) != 0){
        std::remove(nombreTemporal.data());
        return false;
    }
    return true;
}
int Juego::guardar(string nombreArchivo){
    if(!estaInicializado()){
        return 1;
    }
    if(nombreArchivo.empty() || nombreArchivo.find('\0') != string::npos){
        return 3;
    }
    if(nombreArchivo.size() >= 4 && nombreArchivo.substr(nombreArchivo.size() - 4) == ".bin"){
        return 3;
    }
    string texto;
    if(!generarTextoGuardado(texto)){
        return 2;
    }
    if(!escribirArchivoSeguro(nombreArchivo, texto)){
        return 3;
    }
    return 0;
}
void Juego::agregarEnteroBinario(string& contenido, std::uint64_t valor, int bytes) const{
    for(int i = 0; i < bytes; i++){
        contenido.push_back((char)(valor % 256));
        valor /= 256;
    }
}
int Juego::guardarComprimido(string nombreArchivo){
    if(!estaInicializado()){
        return 1;
    }
    if(nombreArchivo.empty() || nombreArchivo.find('\0') != string::npos){
        return 3;
    }
    if(nombreArchivo.size() < 4 || nombreArchivo.substr(nombreArchivo.size() - 4) != ".bin"){
        nombreArchivo += ".bin";
    }
    string texto;
    if(!generarTextoGuardado(texto)){
        return 2;
    }
    if(texto.empty() || texto.size() > 65536){
        return 4;
    }
    vector<std::uint64_t> frecuencias(256, 0);
    int cantidad = 0;
    for(unsigned char caracter : texto){
        if(frecuencias[caracter] == 0){
            cantidad++;
        }
        frecuencias[caracter]++;
    }
    ArbolHuffman arbol;
    if(!arbol.construir(frecuencias)){
        return 4;
    }
    std::uint64_t longitud = 0;
    if(!arbol.consultarLongitudCodificada(longitud)){
        return 4;
    }
    string bits;
    if(!arbol.codificar(texto, bits) || bits.size() != longitud){
        return 4;
    }
    std::uint64_t cantidadBytes = longitud / 8;
    if(longitud % 8 != 0){
        cantidadBytes++;
    }
    std::uint64_t cabecera = 10 + 9 * (std::uint64_t)cantidad;
    string contenido;
    if(cabecera > contenido.max_size() || cantidadBytes > contenido.max_size() - cabecera){
        return 4;
    }
    contenido.reserve((string::size_type)(cabecera + cantidadBytes));
    agregarEnteroBinario(contenido, (std::uint64_t)cantidad, 2);
    for(int i = 0; i < 256; i++){
        if(frecuencias[i] > 0){
            contenido.push_back((char)i);
            agregarEnteroBinario(contenido, frecuencias[i], 8);
        }
    }
    agregarEnteroBinario(contenido, (std::uint64_t)texto.size(), 8);
    unsigned int byteActual = 0;
    int usados = 0;
    for(char bit : bits){
        byteActual *= 2;
        if(bit == '1'){
            byteActual++;
        }
        usados++;
        if(usados == 8){
            contenido.push_back((char)byteActual);
            byteActual = 0;
            usados = 0;
        }
    }
    if(usados > 0){
        while(usados < 8){
            byteActual *= 2;
            usados++;
        }
        contenido.push_back((char)byteActual);
    }
    if(contenido.size() != cabecera + cantidadBytes){
        return 4;
    }
    if(!escribirArchivoSeguro(nombreArchivo, contenido)){
        return 3;
    }
    return 0;
}
bool Juego::leerEnteroBinario(ifstream& archivo, int bytes, std::uint64_t& valor) const{
    if(bytes < 1 || bytes > 8){
        return false;
    }
    std::uint64_t temporal = 0;
    std::uint64_t factor = 1;
    for(int i = 0; i < bytes; i++){
        char caracter;
        if(!archivo.get(caracter)){
            return false;
        }
        temporal += (std::uint64_t)(unsigned char)caracter * factor;
        if(i + 1 < bytes){
            factor *= 256;
        }
    }
    valor = temporal;
    return true;
}
int Juego::leerArchivoComprimido(const string& nombreArchivo, string& texto) const{
    ifstream archivo(nombreArchivo, ios::binary);
    if(!archivo.is_open()){
        return 2;
    }
    if(archivo.peek() == EOF){
        return archivo.bad() ? 2 : 3;
    }
    archivo.seekg(0, ios::end);
    streamoff tamano = archivo.tellg();
    if(tamano < 0){
        return 2;
    }
    if(tamano == 0){
        return 3;
    }
    archivo.seekg(0, ios::beg);
    if(!archivo){
        return 2;
    }
    std::uint64_t cantidad = 0;
    if(!leerEnteroBinario(archivo, 2, cantidad)){
        return archivo.bad() ? 2 : 4;
    }
    if(cantidad < 1 || cantidad > 256){
        return 4;
    }
    std::uint64_t cabecera = 10 + 9 * cantidad;
    if((std::uint64_t)tamano < cabecera){
        return 4;
    }
    vector<std::uint64_t> frecuencias(256, 0);
    std::uint64_t suma = 0;
    for(std::uint64_t i = 0; i < cantidad; i++){
        std::uint64_t caracter = 0;
        std::uint64_t frecuencia = 0;
        if(!leerEnteroBinario(archivo, 1, caracter) || !leerEnteroBinario(archivo, 8, frecuencia)){
            return archivo.bad() ? 2 : 4;
        }
        if(frecuencia == 0 || frecuencias[caracter] != 0){
            return 4;
        }
        if(frecuencia > UINT64_MAX - suma){
            return 4;
        }
        suma += frecuencia;
        frecuencias[caracter] = frecuencia;
    }
    std::uint64_t longitudOriginal = 0;
    if(!leerEnteroBinario(archivo, 8, longitudOriginal)){
        return archivo.bad() ? 2 : 4;
    }
    if(longitudOriginal < 1 || longitudOriginal > 65536 || suma != longitudOriginal){
        return 4;
    }
    ArbolHuffman arbol;
    if(!arbol.construir(frecuencias)){
        return 4;
    }
    std::uint64_t longitud = 0;
    if(!arbol.consultarLongitudCodificada(longitud) || longitud == 0){
        return 4;
    }
    std::uint64_t cantidadBytes = longitud / 8;
    if(longitud % 8 != 0){
        cantidadBytes++;
    }
    if((std::uint64_t)tamano - cabecera != cantidadBytes){
        return 4;
    }
    string contenido;
    string bits;
    if(cantidadBytes > contenido.max_size() || longitud > bits.max_size()){
        return 4;
    }
    contenido.resize((string::size_type)cantidadBytes);
    if(!archivo.read(&contenido[0], (streamsize)cantidadBytes)){
        return archivo.bad() ? 2 : 4;
    }
    if(archivo.peek() != EOF){
        return 4;
    }
    if(archivo.bad()){
        return 2;
    }
    int relleno = (int)((8 - longitud % 8) % 8);
    if(relleno > 0){
        unsigned int divisor = 1;
        for(int i = 0; i < relleno; i++){
            divisor *= 2;
        }
        unsigned int ultimo = (unsigned char)contenido.back();
        if(ultimo % divisor != 0){
            return 4;
        }
    }
    bits.reserve((string::size_type)longitud);
    std::uint64_t restantes = longitud;
    for(unsigned char caracter : contenido){
        unsigned int divisor = 128;
        for(int i = 0; i < 8 && restantes > 0; i++){
            if((caracter / divisor) % 2 == 0){
                bits.push_back('0');
            }else{
                bits.push_back('1');
            }
            divisor /= 2;
            restantes--;
        }
    }
    if(restantes != 0){
        return 4;
    }
    string temporal;
    if(!arbol.decodificar(bits, longitudOriginal, temporal)){
        return 4;
    }
    texto.swap(temporal);
    return 0;
}
bool Juego::extraerToken(const string& texto, string::size_type& posicion, string& token) const{
    if(posicion > texto.size()){
        return false;
    }
    while(posicion < texto.size() && isspace((unsigned char)texto[posicion])){
        posicion++;
    }
    if(posicion == texto.size()){
        return false;
    }
    string::size_type inicio = posicion;
    while(posicion < texto.size() && !isspace((unsigned char)texto[posicion])){
        posicion++;
    }
    token = texto.substr(inicio, posicion - inicio);
    return true;
}
int Juego::cargarTextoGuardado(const string& texto){
    if(texto.size() > 65536){
        return 4;
    }
    string::size_type posicionTexto = 0;
    string token;
    if(!extraerToken(texto, posicionTexto, token)){
        return 3;
    }
    if(token[0] == '+'){
        token.erase(0, 1);
    }
    int cantidadJugadores = 0;
    if(!convertirNumero(token, 6, cantidadJugadores) || cantidadJugadores < 1){
        return 4;
    }
    list<Jugador> jugadoresTemporales;
    for(int i = 0; i < cantidadJugadores; i++){
        string nombre;
        string color;
        if(!extraerToken(texto, posicionTexto, nombre) || !extraerToken(texto, posicionTexto, color)){
            return 4;
        }
        if(nombre.size() > 8 || nombre.find('\0') != string::npos){
            return 4;
        }
        if(color != "rojo" && color != "azul" && color != "verde" && color != "amarillo" && color != "negro" && color != "gris"){
            return 4;
        }
        for(const Jugador& jugador : jugadoresTemporales){
            if(jugador.consultarNombre() == nombre || jugador.consultarColor() == color){
                return 4;
            }
        }
        jugadoresTemporales.push_back(Jugador(nombre, color));
    }
    Tablero tableroTemporal;
    tableroTemporal.crearTablero();
    for(int i = 0; i < 42; i++){
        string codigo;
        string color;
        string cantidad;
        if(!extraerToken(texto, posicionTexto, codigo) || !extraerToken(texto, posicionTexto, color) || !extraerToken(texto, posicionTexto, cantidad)){
            return 4;
        }
        Territorio* territorio = tableroTemporal.buscarTerritorio(codigo);
        if(territorio == nullptr || territorio->tienePropietario()){
            return 4;
        }
        if(cantidad[0] == '+'){
            cantidad.erase(0, 1);
        }
        int unidades = 0;
        if(!convertirNumero(cantidad, INT_MAX, unidades) || unidades < 1){
            return 4;
        }
        Jugador* propietario = nullptr;
        for(Jugador& jugador : jugadoresTemporales){
            if(jugador.consultarColor() == color){
                propietario = &jugador;
                break;
            }
        }
        if(propietario == nullptr){
            return 4;
        }
        territorio->asignarPropietario(color);
        territorio->agregarUnidades(unidades);
        propietario->agregarTerritorio(codigo);
    }
    if(extraerToken(texto, posicionTexto, token)){
        return 4;
    }
    for(const Jugador& jugador : jugadoresTemporales){
        if(jugador.consultarTerritorios().empty()){
            return 4;
        }
    }
    Mazo mazoTemporal;
    mazoTemporal.crearMazo(tableroTemporal);
    jugadores = jugadoresTemporales;
    tablero = tableroTemporal;
    mazo = mazoTemporal;
    turnoActual = 0;
    fase = "obtener_unidades";
    return 0;
}


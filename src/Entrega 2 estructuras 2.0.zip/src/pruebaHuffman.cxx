#include <iostream>
#include <string>
#include <vector>
#include "ArbolHuffman.h"
std::vector<std::uint64_t> contarFrecuencias(const std::string& texto){
    std::vector<std::uint64_t> frecuencias(256, 0);
    for(unsigned char caracter : texto){
        frecuencias[caracter]++;
    }
    return frecuencias;
}
int verificar(bool condicion, const std::string& descripcion){
    if(condicion){
        std::cout << "[OK] " << descripcion << std::endl;
        return 0;
    }
    std::cout << "[ERROR] " << descripcion << std::endl;
    return 1;
}
bool comprobarTexto(const std::string& original){
    ArbolHuffman arbol;
    if(!arbol.construir(contarFrecuencias(original))){
        return false;
    }
    std::string bits = "salida anterior";
    if(!arbol.codificar(original, bits)){
        return false;
    }
    std::uint64_t longitud = 0;
    if(!arbol.consultarLongitudCodificada(longitud) || longitud != bits.size()){
        return false;
    }
    std::string recuperado = "salida anterior";
    if(!arbol.decodificar(bits, original.size(), recuperado)){
        return false;
    }
    return recuperado == original;
}
int main(){
    int fallos = 0;
    fallos += verificar(comprobarTexto("Risk con espacios y saltos\nde linea\n"), "Texto con espacios y saltos de linea");
    fallos += verificar(comprobarTexto(""), "Texto vacio");
    fallos += verificar(comprobarTexto("AAAAAA"), "Un solo simbolo repetido");
    fallos += verificar(comprobarTexto(std::string(8, '\0')), "Bytes de valor cero");
    std::string todos;
    for(int i = 0; i < 256; i++){
        todos.push_back((char)i);
    }
    fallos += verificar(comprobarTexto(todos), "Los 256 valores de byte");
    ArbolHuffman arbol;
    std::vector<std::uint64_t> frecuencias = contarFrecuencias("ABBA");
    bool construido = arbol.construir(frecuencias);
    std::vector<std::string> codigos = arbol.generarCodigos();
    std::string bits;
    bool correcto = construido && codigos.size() == 256;
    if(correcto){
        correcto = codigos['A'] == "0" && codigos['B'] == "1";
    }
    correcto = correcto && arbol.codificar("ABBA", bits) && bits == "0110";
    fallos += verificar(correcto, "Desempate: A = 0, B = 1, ABBA = 0110");
    ArbolHuffman reconstruido;
    std::string recuperado;
    correcto = reconstruido.construir(frecuencias);
    correcto = correcto && reconstruido.generarCodigos() == codigos;
    correcto = correcto && reconstruido.decodificar("0110", 4, recuperado) && recuperado == "ABBA";
    fallos += verificar(correcto, "Reconstruccion con las mismas frecuencias");
    const NodoHuffman* raizAnterior = arbol.consultarRaiz();
    std::vector<std::uint64_t> incompletas(255, 0);
    correcto = !arbol.construir(incompletas) && arbol.consultarRaiz() == raizAnterior;
    fallos += verificar(correcto, "Vector invalido conserva el arbol anterior");
    std::vector<std::uint64_t> desborde(256, 0);
    desborde['A'] = UINT64_MAX;
    desborde['B'] = 1;
    correcto = !arbol.construir(desborde) && arbol.consultarRaiz() == raizAnterior;
    fallos += verificar(correcto, "Suma desbordada conserva el arbol anterior");
    bits = "sin cambios";
    correcto = !arbol.codificar("AAAA", bits) && bits == "sin cambios";
    fallos += verificar(correcto, "Codificacion rechaza frecuencias distintas sin cambiar la salida");
    recuperado = "sin cambios";
    correcto = !arbol.decodificar("01x0", 4, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Rechaza caracteres distintos de 0 y 1");
    recuperado = "sin cambios";
    correcto = !arbol.decodificar("011", 4, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Rechaza una secuencia truncada");
    recuperado = "sin cambios";
    correcto = !arbol.decodificar("01100", 4, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Rechaza bits adicionales sin cambiar la salida");
    recuperado = "sin cambios";
    correcto = !arbol.decodificar("0110", 3, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Rechaza una longitud original incorrecta");
    recuperado = "sin cambios";
    correcto = !arbol.decodificar("0000", 4, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Rechaza frecuencias decodificadas incorrectas");
    ArbolHuffman unico;
    correcto = unico.construir(contarFrecuencias("AAAA"));
    bits = "anterior";
    correcto = correcto && unico.codificar("AAAA", bits) && bits == "0000";
    recuperado = "sin cambios";
    correcto = correcto && !unico.decodificar("0001", 4, recuperado) && recuperado == "sin cambios";
    fallos += verificar(correcto, "Un solo simbolo utiliza exclusivamente ceros");
    ArbolHuffman grande;
    std::vector<std::uint64_t> enormes(256, 0);
    enormes['A'] = UINT64_MAX / 2;
    enormes['B'] = UINT64_MAX / 2;
    enormes['C'] = 1;
    correcto = grande.construir(enormes);
    std::uint64_t longitud = 77;
    correcto = correcto && !grande.consultarLongitudCodificada(longitud) && longitud == 77;
    fallos += verificar(correcto, "Longitud codificada desbordada conserva el resultado anterior");
    arbol.vaciar();
    correcto = arbol.estaVacio() && arbol.consultarRaiz() == nullptr;
    correcto = correcto && arbol.construir(frecuencias);
    bits = "anterior";
    correcto = correcto && arbol.codificar("ABBA", bits) && bits == "0110";
    fallos += verificar(correcto, "Vaciar permite reutilizar el arbol");
    if(fallos == 0){
        std::cout << "RESULTADO: PRUEBAS CORRECTAS" << std::endl;
        return 0;
    }
    std::cout << "RESULTADO: " << fallos << " PRUEBAS FALLIDAS" << std::endl;
    return 1;
}

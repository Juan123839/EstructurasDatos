#include "ColaPrioridadMinima.h"
ColaPrioridadMinima::ColaPrioridadMinima(){
}
ColaPrioridadMinima::~ColaPrioridadMinima(){
    for(NodoHuffman* nodo : elementos){
        delete nodo;
    }
}
bool ColaPrioridadMinima::esMenor(const NodoHuffman* primero, const NodoHuffman* segundo) const{
    if(primero->consultarFrecuencia() != segundo->consultarFrecuencia()){
        return primero->consultarFrecuencia() < segundo->consultarFrecuencia();
    }
    return primero->consultarByteMinimo() < segundo->consultarByteMinimo();
}
void ColaPrioridadMinima::subir(int posicion){
    while(posicion > 0){
        int padre = (posicion - 1) / 2;
        if(!esMenor(elementos[posicion], elementos[padre])){
            return;
        }
        NodoHuffman* auxiliar = elementos[posicion];
        elementos[posicion] = elementos[padre];
        elementos[padre] = auxiliar;
        posicion = padre;
    }
}
void ColaPrioridadMinima::bajar(int posicion){
    int cantidad = consultarCantidad();
    while(true){
        int menor = posicion;
        int izquierdo = 2 * posicion + 1;
        int derecho = 2 * posicion + 2;
        if(izquierdo < cantidad && esMenor(elementos[izquierdo], elementos[menor])){
            menor = izquierdo;
        }
        if(derecho < cantidad && esMenor(elementos[derecho], elementos[menor])){
            menor = derecho;
        }
        if(menor == posicion){
            return;
        }
        NodoHuffman* auxiliar = elementos[posicion];
        elementos[posicion] = elementos[menor];
        elementos[menor] = auxiliar;
        posicion = menor;
    }
}
bool ColaPrioridadMinima::estaVacia() const{
    return elementos.empty();
}
int ColaPrioridadMinima::consultarCantidad() const{
    return (int)elementos.size();
}
const NodoHuffman* ColaPrioridadMinima::consultarMinimo() const{
    if(estaVacia()){
        return nullptr;
    }
    return elementos[0];
}
void ColaPrioridadMinima::insertar(NodoHuffman* nodo){
    elementos.push_back(nodo);
    subir(consultarCantidad() - 1);
}
NodoHuffman* ColaPrioridadMinima::extraerMinimo(){
    NodoHuffman* minimo = elementos[0];
    elementos[0] = elementos.back();
    elementos.pop_back();
    if(!estaVacia()){
        bajar(0);
    }
    return minimo;
}
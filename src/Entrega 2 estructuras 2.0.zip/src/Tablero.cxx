#include "Tablero.h"
using namespace std;
Tablero::Tablero(){
}
void Tablero::crearTablero(){
    continentes.clear();
    Continente americaNorte("America del Norte");
    Continente americaSur("America del Sur");
    Continente europa("Europa");
    Continente africa("Africa");
    Continente asia("Asia");
    Continente australia("Australia");
    Territorio alaska("1.1", "Alaska");
    Territorio noroeste("1.6", "Territorio del Noroeste");
    Territorio groenlandia("1.5", "Groenlandia");
    Territorio alberta("1.2", "Alberta");
    Territorio ontario("1.7", "Ontario");
    Territorio quebec("1.8", "Quebec");
    Territorio oeste("1.9", "Estados Unidos Occidental");
    Territorio este("1.4", "Estados Unidos Oriental");
    Territorio central("1.3", "America Central");
    americaNorte.agregarTerritorio(alaska);
    americaNorte.agregarTerritorio(alberta);
    americaNorte.agregarTerritorio(central);
    americaNorte.agregarTerritorio(este);
    americaNorte.agregarTerritorio(groenlandia);
    americaNorte.agregarTerritorio(noroeste);
    americaNorte.agregarTerritorio(ontario);
    americaNorte.agregarTerritorio(quebec);
    americaNorte.agregarTerritorio(oeste);
    Territorio venezuela("2.4", "Venezuela");
    Territorio brasil("2.2", "Brasil");
    Territorio peru("2.3", "Peru");
    Territorio argentina("2.1", "Argentina");
    americaSur.agregarTerritorio(argentina);
    americaSur.agregarTerritorio(brasil);
    americaSur.agregarTerritorio(peru);
    americaSur.agregarTerritorio(venezuela);
    Territorio islandia("3.2", "Islandia");
    Territorio escandinavia("3.4", "Escandinavia");
    Territorio ucrania("3.6", "Ucrania");
    Territorio granBretana("3.1", "Gran Bretana");
    Territorio europaOccidental("3.7", "Europa Occidental");
    Territorio europaNorte("3.3", "Europa del Norte");
    Territorio europaSur("3.5", "Europa del Sur");
    europa.agregarTerritorio(granBretana);
    europa.agregarTerritorio(islandia);
    europa.agregarTerritorio(europaNorte);
    europa.agregarTerritorio(escandinavia);
    europa.agregarTerritorio(europaSur);
    europa.agregarTerritorio(ucrania);
    europa.agregarTerritorio(europaOccidental);
    Territorio norteAfrica("4.5", "Africa del Norte");
    Territorio egipto("4.3", "Egipto");
    Territorio oriental("4.2", "Africa Oriental");
    Territorio congo("4.1", "Congo");
    Territorio surAfrica("4.6", "Africa del Sur");
    Territorio madagascar("4.4", "Madagascar");
    africa.agregarTerritorio(congo);
    africa.agregarTerritorio(oriental);
    africa.agregarTerritorio(egipto);
    africa.agregarTerritorio(madagascar);
    africa.agregarTerritorio(norteAfrica);
    africa.agregarTerritorio(surAfrica);
    Territorio ural("5.11", "Ural");
    Territorio siberia("5.10", "Siberia");
    Territorio yakutsk("5.12", "Yakutsk");
    Territorio kamchatka("5.6", "Kamchatka");
    Territorio japon("5.5", "Japon");
    Territorio mongolia("5.8", "Mongolia");
    Territorio china("5.2", "China");
    Territorio india("5.3", "India");
    Territorio medioOriente("5.7", "Medio Oriente");
    Territorio afganistan("5.1", "Afganistan");
    Territorio irkutsk("5.4", "Irkutsk");
    Territorio siam("5.9", "Siam");
    asia.agregarTerritorio(afganistan);
    asia.agregarTerritorio(china);
    asia.agregarTerritorio(india);
    asia.agregarTerritorio(irkutsk);
    asia.agregarTerritorio(japon);
    asia.agregarTerritorio(kamchatka);
    asia.agregarTerritorio(medioOriente);
    asia.agregarTerritorio(mongolia);
    asia.agregarTerritorio(siam);
    asia.agregarTerritorio(siberia);
    asia.agregarTerritorio(ural);
    asia.agregarTerritorio(yakutsk);
    Territorio indonesia("6.2", "Indonesia");
    Territorio nuevaGuinea("6.3", "Nueva Guinea");
    Territorio australiaOccidental("6.4", "Australia Occidental");
    Territorio australiaOriental("6.1", "Australia Oriental");
    australia.agregarTerritorio(australiaOriental);
    australia.agregarTerritorio(indonesia);
    australia.agregarTerritorio(nuevaGuinea);
    australia.agregarTerritorio(australiaOccidental);
    continentes.push_back(americaNorte);
    continentes.push_back(americaSur);
    continentes.push_back(europa);
    continentes.push_back(africa);
    continentes.push_back(asia);
    continentes.push_back(australia);
    // America del Norte y sus conexiones externas.
    conectarTerritorios("1.1", "1.6");
    conectarTerritorios("1.1", "1.2");
    conectarTerritorios("1.1", "5.6");
    conectarTerritorios("1.6", "1.5");
    conectarTerritorios("1.6", "1.2");
    conectarTerritorios("1.6", "1.7");
    conectarTerritorios("1.5", "1.7");
    conectarTerritorios("1.5", "1.8");
    conectarTerritorios("1.5", "3.2");
    conectarTerritorios("1.2", "1.7");
    conectarTerritorios("1.2", "1.9");
    conectarTerritorios("1.7", "1.8");
    conectarTerritorios("1.7", "1.9");
    conectarTerritorios("1.7", "1.4");
    conectarTerritorios("1.8", "1.4");
    conectarTerritorios("1.9", "1.4");
    conectarTerritorios("1.9", "1.3");
    conectarTerritorios("1.4", "1.3");
    conectarTerritorios("1.3", "2.4");
    // America del Sur.
    conectarTerritorios("2.4", "2.2");
    conectarTerritorios("2.4", "2.3");
    conectarTerritorios("2.2", "2.3");
    conectarTerritorios("2.2", "2.1");
    conectarTerritorios("2.2", "4.5");
    conectarTerritorios("2.3", "2.1");
    // Europa.
    conectarTerritorios("3.2", "3.4");
    conectarTerritorios("3.2", "3.1");
    conectarTerritorios("3.1", "3.4");
    conectarTerritorios("3.4", "3.6");
    conectarTerritorios("3.4", "3.3");
    conectarTerritorios("3.6", "3.3");
    conectarTerritorios("3.6", "3.5");
    conectarTerritorios("3.6", "5.11");
    conectarTerritorios("3.6", "5.1");
    conectarTerritorios("3.6", "5.7");
    conectarTerritorios("3.1", "3.7");
    conectarTerritorios("3.1", "3.3");
    conectarTerritorios("3.7", "3.3");
    conectarTerritorios("3.7", "3.5");
    conectarTerritorios("3.7", "4.5");
    conectarTerritorios("3.3", "3.5");
    conectarTerritorios("3.5", "4.5");
    conectarTerritorios("3.5", "4.3");
    conectarTerritorios("3.5", "5.7");
    // Africa.
    conectarTerritorios("4.5", "4.3");
    conectarTerritorios("4.5", "4.2");
    conectarTerritorios("4.5", "4.1");
    conectarTerritorios("4.3", "4.2");
    conectarTerritorios("4.3", "5.7");
    conectarTerritorios("4.2", "4.1");
    conectarTerritorios("4.2", "4.6");
    conectarTerritorios("4.2", "4.4");
    conectarTerritorios("4.2", "5.7");
    conectarTerritorios("4.1", "4.6");
    conectarTerritorios("4.6", "4.4");
    // Asia.
    conectarTerritorios("5.11", "5.10");
    conectarTerritorios("5.11", "5.2");
    conectarTerritorios("5.11", "5.1");
    conectarTerritorios("5.10", "5.12");
    conectarTerritorios("5.10", "5.8");
    conectarTerritorios("5.10", "5.2");
    conectarTerritorios("5.10", "5.4");
    conectarTerritorios("5.12", "5.6");
    conectarTerritorios("5.12", "5.4");
    conectarTerritorios("5.6", "5.5");
    conectarTerritorios("5.6", "5.8");
    conectarTerritorios("5.6", "5.4");
    conectarTerritorios("5.5", "5.8");
    conectarTerritorios("5.8", "5.2");
    conectarTerritorios("5.8", "5.4");
    conectarTerritorios("5.2", "5.3");
    conectarTerritorios("5.2", "5.1");
    conectarTerritorios("5.2", "5.9");
    conectarTerritorios("5.3", "5.7");
    conectarTerritorios("5.3", "5.1");
    conectarTerritorios("5.3", "5.9");
    conectarTerritorios("5.7", "5.1");
    conectarTerritorios("5.9", "6.2");
    // Australia.
    conectarTerritorios("6.2", "6.3");
    conectarTerritorios("6.2", "6.4");
    conectarTerritorios("6.3", "6.4");
    conectarTerritorios("6.3", "6.1");
    conectarTerritorios("6.4", "6.1");
}
list<Continente>& Tablero::consultarContinentes(){
    return continentes;
}
bool Tablero::existeTerritorio(string codigo) const{
    for(const Continente& continente : continentes){
        if(continente.contieneTerritorio(codigo)){
            return true;
        }
    }
    return false;
}
Territorio* Tablero::buscarTerritorio(string codigo){
    for(Continente& continente : continentes){
        list<Territorio>& territorios = continente.consultarTerritorios();
        for(Territorio& territorio : territorios){
            if(territorio.consultarCodigo() == codigo){
                return &territorio;
            }
        }
    }
    return nullptr;
}
list<Territorio*> Tablero::consultarTerritorios(){
    list<Territorio*> resultado;
    for(Continente& continente : continentes){
        list<Territorio>& territorios = continente.consultarTerritorios();
        for(Territorio& territorio : territorios){
            resultado.push_back(&territorio);
        }
    }
    return resultado;
}
int Tablero::contarTerritoriosDe(string color) const{
    int contador = 0;
    for(const Continente& continente : continentes){
        contador = contador + continente.contarTerritoriosDe(color);
    }
    return contador;
}
int Tablero::calcularBonificacionPorContinentes(string color) const{
    int bonificacion = 0;
    for(const Continente& continente : continentes){
        if(continente.esControladoPor(color)){
            bonificacion = bonificacion + continente.consultarBonificacion();
        }
    }
    return bonificacion;
}
bool Tablero::controlaTodoElTablero(string color) const{
    if(color == ""){
        return false;
    }
    return contarTerritoriosDe(color) == 42;
}
void Tablero::conectarTerritorios(string codigo1, string codigo2){
    if(codigo1 == codigo2){
        return;
    }
    Territorio* territorio1 = buscarTerritorio(codigo1);
    Territorio* territorio2 = buscarTerritorio(codigo2);
    if(territorio1 == nullptr || territorio2 == nullptr){
        return;
    }
    territorio1->agregarVecino(codigo2);
    territorio2->agregarVecino(codigo1);
}
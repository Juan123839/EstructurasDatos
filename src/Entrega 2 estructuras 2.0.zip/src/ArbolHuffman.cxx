#include "ArbolHuffman.h"
#include "ColaPrioridadMinima.h"
ArbolHuffman::ArbolHuffman(){
    raiz = nullptr;
}
ArbolHuffman::~ArbolHuffman(){
    vaciar();
}
bool ArbolHuffman::estaVacio() const{
    return raiz == nullptr;
}
const NodoHuffman* ArbolHuffman::consultarRaiz() const{
    return raiz;
}
bool ArbolHuffman::construir(const std::vector<std::uint64_t>& frecuencias){
    if(frecuencias.size() != 256){
        return false;
    }
    std::uint64_t total = 0;
    int cantidad = 0;
    int unico = -1;
    for(int i = 0; i < 256; i++){
        if(frecuencias[i] > UINT64_MAX - total){
            return false;
        }
        total += frecuencias[i];
        if(frecuencias[i] > 0){
            cantidad++;
            unico = i;
        }
    }
    if(cantidad == 0){
        vaciar();
        return true;
    }
    if(cantidad == 1){
        NodoHuffman* nuevaRaiz = new NodoHuffman((unsigned char)unico, frecuencias[unico]);
        vaciar();
        raiz = nuevaRaiz;
        return true;
    }
    ColaPrioridadMinima cola;
    for(int i = 0; i < 256; i++){
        if(frecuencias[i] > 0){
            cola.insertar(new NodoHuffman((unsigned char)i, frecuencias[i]));
        }
    }
    while(cola.consultarCantidad() > 1){
        NodoHuffman* izquierdo = cola.extraerMinimo();
        NodoHuffman* derecho = cola.extraerMinimo();
        NodoHuffman* padre = new NodoHuffman(izquierdo, derecho);
        cola.insertar(padre);
    }
    NodoHuffman* nuevaRaiz = cola.extraerMinimo();
    vaciar();
    raiz = nuevaRaiz;
    return true;
}
void ArbolHuffman::generarCodigosRec(const NodoHuffman* nodo, std::string codigo, std::vector<std::string>& codigos) const{
    if(nodo == nullptr){
        return;
    }
    if(nodo->esHoja()){
        if(codigo.empty()){
            codigo = "0";
        }
        codigos[nodo->consultarCaracter()] = codigo;
        return;
    }
    generarCodigosRec(nodo->consultarHijoIzq(), codigo + "0", codigos);
    generarCodigosRec(nodo->consultarHijoDer(), codigo + "1", codigos);
}
std::vector<std::string> ArbolHuffman::generarCodigos() const{
    std::vector<std::string> codigos(256);
    generarCodigosRec(raiz, "", codigos);
    return codigos;
}
bool ArbolHuffman::calcularLongitudRec(const NodoHuffman* nodo, std::uint64_t profundidad, std::uint64_t& longitud) const{
    if(nodo == nullptr){
        return true;
    }
    if(nodo->esHoja()){
        std::uint64_t longitudCodigo = profundidad;
        if(longitudCodigo == 0){
            longitudCodigo = 1;
        }
        std::uint64_t frecuencia = nodo->consultarFrecuencia();
        if(frecuencia > UINT64_MAX / longitudCodigo){
            return false;
        }
        std::uint64_t aporte = frecuencia * longitudCodigo;
        if(aporte > UINT64_MAX - longitud){
            return false;
        }
        longitud += aporte;
        return true;
    }
    if(!calcularLongitudRec(nodo->consultarHijoIzq(), profundidad + 1, longitud)){
        return false;
    }
    return calcularLongitudRec(nodo->consultarHijoDer(), profundidad + 1, longitud);
}
bool ArbolHuffman::consultarLongitudCodificada(std::uint64_t& longitud) const{
    std::uint64_t temporal = 0;
    if(!calcularLongitudRec(raiz, 0, temporal)){
        return false;
    }
    longitud = temporal;
    return true;
}
void ArbolHuffman::obtenerFrecuenciasRec(const NodoHuffman* nodo, std::vector<std::uint64_t>& frecuencias) const{
    if(nodo == nullptr){
        return;
    }
    if(nodo->esHoja()){
        frecuencias[nodo->consultarCaracter()] = nodo->consultarFrecuencia();
        return;
    }
    obtenerFrecuenciasRec(nodo->consultarHijoIzq(), frecuencias);
    obtenerFrecuenciasRec(nodo->consultarHijoDer(), frecuencias);
}
bool ArbolHuffman::codificar(const std::string& texto, std::string& bits) const{
    std::uint64_t longitud = 0;
    if(!consultarLongitudCodificada(longitud)){
        return false;
    }
    std::string temporal;
    if(longitud > temporal.max_size()){
        return false;
    }
    std::vector<std::uint64_t> esperadas(256, 0);
    std::vector<std::uint64_t> encontradas(256, 0);
    obtenerFrecuenciasRec(raiz, esperadas);
    for(unsigned char caracter : texto){
        if(encontradas[caracter] == UINT64_MAX){
            return false;
        }
        encontradas[caracter]++;
    }
    if(encontradas != esperadas){
        return false;
    }
    std::vector<std::string> codigos = generarCodigos();
    temporal.reserve((std::string::size_type)longitud);
    for(unsigned char caracter : texto){
        temporal += codigos[caracter];
    }
    bits.swap(temporal);
    return true;
}
bool ArbolHuffman::decodificar(const std::string& bits, std::uint64_t longitudOriginal, std::string& texto) const{
    std::uint64_t longitud = 0;
    if(!consultarLongitudCodificada(longitud) || longitud != bits.size()){
        return false;
    }
    std::string temporal;
    if(longitudOriginal > temporal.max_size()){
        return false;
    }
    if(estaVacio()){
        if(longitudOriginal != 0 || !bits.empty()){
            return false;
        }
        texto.swap(temporal);
        return true;
    }
    if(longitudOriginal != raiz->consultarFrecuencia()){
        return false;
    }
    for(char bit : bits){
        if(bit != '0' && bit != '1'){
            return false;
        }
    }
    if(raiz->esHoja()){
        for(char bit : bits){
            if(bit != '0'){
                return false;
            }
        }
        temporal.assign((std::string::size_type)longitudOriginal, (char)raiz->consultarCaracter());
        texto.swap(temporal);
        return true;
    }
    std::vector<std::uint64_t> esperadas(256, 0);
    std::vector<std::uint64_t> recuperadas(256, 0);
    obtenerFrecuenciasRec(raiz, esperadas);
    temporal.reserve((std::string::size_type)longitudOriginal);
    const NodoHuffman* actual = raiz;
    for(char bit : bits){
        if(bit == '0'){
            actual = actual->consultarHijoIzq();
        }else{
            actual = actual->consultarHijoDer();
        }
        if(actual == nullptr){
            return false;
        }
        if(actual->esHoja()){
            unsigned char caracter = actual->consultarCaracter();
            if(temporal.size() >= longitudOriginal || recuperadas[caracter] >= esperadas[caracter]){
                return false;
            }
            recuperadas[caracter]++;
            temporal.push_back((char)caracter);
            actual = raiz;
        }
    }
    if(actual != raiz || temporal.size() != longitudOriginal || recuperadas != esperadas){
        return false;
    }
    texto.swap(temporal);
    return true;
}
void ArbolHuffman::vaciar(){
    delete raiz;
    raiz = nullptr;
}
